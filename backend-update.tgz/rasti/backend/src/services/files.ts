// Извлечение содержимого из загруженных файлов (вложения в чат и база знаний).
// Картинки отдаём как data-URI для vision-модели (gpt-4o «видит» изображение),
// PDF и текстовые форматы — извлекаем текст и подставляем в контекст.
import { PDFParse } from 'pdf-parse';

export interface ExtractedFile {
  name: string;
  kind: 'image' | 'text' | 'unsupported';
  text?: string; // для pdf/текстовых — извлечённый текст
  dataUri?: string; // для картинок — data:<mime>;base64,... (для vision)
  error?: string; // причина, если извлечь не удалось
}

const IMAGE_MIME = new Set(['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif']);
const TEXT_MIME = new Set([
  'text/plain',
  'text/markdown',
  'text/csv',
  'application/json',
  'text/html',
]);

// Лимит на длину извлечённого текста, чтобы не раздувать промпт (≈ 30k символов).
const MAX_TEXT = 30000;

function clip(text: string): string {
  const t = text.trim();
  return t.length > MAX_TEXT ? t.slice(0, MAX_TEXT) + '\n…[текст обрезан]' : t;
}

export async function extractFile(buf: Buffer, mime: string, name: string): Promise<ExtractedFile> {
  const lowerName = (name || '').toLowerCase();
  const m = (mime || '').toLowerCase();

  // Картинки → data-URI для vision
  if (IMAGE_MIME.has(m) || /\.(png|jpe?g|webp|gif)$/.test(lowerName)) {
    const realMime = IMAGE_MIME.has(m) ? m : 'image/png';
    return { name, kind: 'image', dataUri: `data:${realMime};base64,${buf.toString('base64')}` };
  }

  // PDF → извлечение текста
  if (m === 'application/pdf' || lowerName.endsWith('.pdf')) {
    try {
      const parser = new PDFParse({ data: new Uint8Array(buf) });
      const result = await parser.getText();
      const text = clip(result.text ?? '');
      if (!text) {
        return { name, kind: 'unsupported', error: 'В PDF не найден текст (возможно, это скан).' };
      }
      return { name, kind: 'text', text };
    } catch (e) {
      return { name, kind: 'unsupported', error: `Не удалось прочитать PDF: ${(e as Error).message}` };
    }
  }

  // Текстовые форматы → как есть
  if (TEXT_MIME.has(m) || /\.(txt|md|csv|json|html?)$/.test(lowerName)) {
    return { name, kind: 'text', text: clip(buf.toString('utf8')) };
  }

  return { name, kind: 'unsupported', error: 'Формат файла не поддерживается.' };
}
