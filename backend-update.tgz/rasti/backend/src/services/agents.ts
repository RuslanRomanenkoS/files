// Реестр и роутер агентов («один бот — N веток»). Источник — хранилище (БД),
// чтобы агентов можно было создавать/править через админ-панель.
import { store } from '../store.js';
import type { AgentConfig } from '../types.js';

export function listAgents(includeDisabled = false): Promise<AgentConfig[]> {
  return store.listAgents(includeDisabled);
}

export function getAgent(agentId: string): Promise<AgentConfig | undefined> {
  return store.getAgentConfig(agentId);
}

// Публичное представление агента (без системного промпта/знаний — клиенту не нужно).
export function publicAgent(a: AgentConfig) {
  return { id: a.id, title: a.title, buttonLabel: a.buttonLabel, tariff: a.tariff };
}
