// Контроль расходов: лимиты запросов в день по тарифу.
// Защищает от «нажигания» бюджета ProxyAPI отдельным пользователем.
import { store } from '../store.js';
import type { Tariff } from '../types.js';

const DAILY_REQUEST_LIMIT: Record<Tariff, number> = {
  personal: 50,  // «База личных продаж»
  team: 150,     // «База командных продаж»
};

export interface LimitResult {
  allowed: boolean;
  used: number;
  limit: number;
}

export async function checkDailyLimit(telegramId: number, tariff: Tariff): Promise<LimitResult> {
  const limit = DAILY_REQUEST_LIMIT[tariff];
  const used = (await store.getUsageToday(telegramId)).requests;
  return { allowed: used < limit, used, limit };
}
