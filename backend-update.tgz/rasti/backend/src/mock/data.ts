// Моки на время разработки. Агенты — это «ветки» одного бота.
// systemPrompt пока заглушки: на этапе интеграции сюда вставляются
// реальные Instructions из Custom GPT, а knowledgeRefs наполняются базой знаний.

import type { AgentSeed, User } from '../types.js';

export const demoUsers: User[] = [
  {
    telegramId: 123456789,
    name: 'Руслан',
    gcEmail: 'demo@example.com',
    gcUserId: 'gc-1',
    tariff: 'team',
    accessActive: true,
    accessUntil: '2026-12-31',
  },
  {
    telegramId: 111,
    name: 'Тест (доступ истёк)',
    gcEmail: 'expired@example.com',
    gcUserId: 'gc-2',
    tariff: 'personal',
    accessActive: false,
    accessUntil: '2026-01-01',
  },
];

export const agentSeed: AgentSeed[] = [
  {
    id: 'test',
    title: 'Тестовый агент (возражения)',
    buttonLabel: 'Тест: возражения',
    tariff: 'personal',
    systemPrompt:
      'Задай мне несколько вопросов, чтобы узнать мою сферу, в которой я работаю в ОП, ' +
      'а потом создай таблицу с 10 самыми популярными возражениями в моей сфере и ответами на них.',
  },
  {
    id: 'offer',
    title: 'Сильный оффер',
    buttonLabel: 'Прокачать оффер',
    tariff: 'personal',
    systemPrompt:
      'Ты — эксперт по созданию сильных офферов. Помогаешь пользователю собрать ' +
      'оффер на ЦА и на продукт по проверенным методикам. Задавай уточняющие вопросы ' +
      'по одному. Финальный результат оформляй таблицей. [ЗАГЛУШКА: заменить на Instructions из Custom GPT]',
  },
  {
    id: 'funnel',
    title: 'Воронка продаж',
    buttonLabel: 'Собрать воронку',
    tariff: 'personal',
    systemPrompt: 'Ты — эксперт по воронкам продаж. [ЗАГЛУШКА]',
  },
  {
    id: 'scripts',
    title: 'Скрипты продаж',
    buttonLabel: 'Создать скрипт',
    tariff: 'personal',
    systemPrompt: 'Ты — эксперт по скриптам продаж. [ЗАГЛУШКА]',
  },
  {
    id: 'correspondence',
    title: 'Продажи в переписке',
    buttonLabel: 'Прокачать переписку',
    tariff: 'personal',
    systemPrompt: 'Ты — эксперт по продажам в переписке. [ЗАГЛУШКА]',
  },
  {
    id: 'touches',
    title: 'Цепочки касаний',
    buttonLabel: 'Построить цепочку',
    tariff: 'personal',
    systemPrompt: 'Ты — эксперт по цепочкам касаний до оплаты. [ЗАГЛУШКА]',
  },
  {
    id: 'proposal',
    title: 'Коммерческое предложение',
    buttonLabel: 'Собрать КП',
    tariff: 'personal',
    systemPrompt: 'Ты — эксперт по коммерческим предложениям. [ЗАГЛУШКА]',
  },
  {
    id: 'managers',
    title: 'Управление менеджерами',
    buttonLabel: 'Прокачать команду',
    tariff: 'team',
    systemPrompt: 'Ты — эксперт по управлению отделом продаж. [ЗАГЛУШКА]',
  },
];
