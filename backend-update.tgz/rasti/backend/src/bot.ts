// Telegram-бот — точка входа в Mini App.
// /start => кнопка, открывающая Mini App. Также ставит кнопку меню (слева от поля ввода).
import { Bot } from 'grammy';
import { config } from './config.js';

const token = config.telegram.botToken;
const webappUrl = config.telegram.webappUrl;

if (!token) {
  console.error('Нет TELEGRAM_BOT_TOKEN в .env');
  process.exit(1);
}
if (!webappUrl) {
  console.error('Нет WEBAPP_URL в .env (публичный HTTPS-адрес Mini App)');
  process.exit(1);
}

const bot = new Bot(token);

// Кнопка меню «Открыть» рядом с полем ввода — запускает Mini App
await bot.api.setChatMenuButton({
  menu_button: { type: 'web_app', text: 'Открыть', web_app: { url: webappUrl } },
});

bot.command('start', async (ctx) => {
  await ctx.reply(
    'Добро пожаловать в «Прокачку продаж»! 🚀\n\n' +
      'Нажми кнопку ниже, чтобы открыть приложение с уроками и ИИ-агентами.',
    {
      reply_markup: {
        inline_keyboard: [[{ text: '📚 Открыть приложение', web_app: { url: webappUrl } }]],
      },
    },
  );
});

bot.catch((err) => console.error('Bot error:', err));

console.log('Бот запущен. Откройте его в Telegram и отправьте /start');
console.log(`Mini App URL: ${webappUrl}`);
await bot.start();
