// Проверка доступа. Источник истины — Геткурс (через вебхуки/сверку),
// здесь — решение на основе актуальной копии в нашей БД.
import type { Tariff, User } from '../types.js';

export interface AccessResult {
  allowed: boolean;
  reason?: 'no_access' | 'tariff_locked';
}

// Доступ к курсу в принципе активен?
export function checkAccess(user: User): AccessResult {
  if (!user.accessActive) return { allowed: false, reason: 'no_access' };
  if (user.accessUntil && new Date(user.accessUntil) < new Date()) {
    return { allowed: false, reason: 'no_access' };
  }
  return { allowed: true };
}

// team включает personal; personal не видит team-контент.
export function hasTariff(userTariff: Tariff, needed: Tariff): boolean {
  if (needed === 'personal') return true;
  return userTariff === 'team';
}

// Полная проверка доступа к конкретному агенту.
export function checkAgentAccess(user: User, agentTariff: Tariff): AccessResult {
  const base = checkAccess(user);
  if (!base.allowed) return base;
  if (!hasTariff(user.tariff, agentTariff)) return { allowed: false, reason: 'tariff_locked' };
  return { allowed: true };
}
