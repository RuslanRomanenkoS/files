// Админ-панель: один общий вход (пароль в .env) + подписанный сессионный токен.
// Все маршруты под /api/admin. Логин открыт, остальное защищено adminAuth.
import crypto from 'node:crypto';
import { Router, type Request, type Response, type NextFunction } from 'express';
import { config } from './config.js';
import { store } from './store.js';
import { chatComplete } from './services/llm.js';
import { extractFile } from './services/files.js';
import type { AgentConfig, ChatMessage, Tariff } from './types.js';

// --- Токен сессии (HMAC, со сроком жизни) ---
function secret(): string {
  return config.admin.tokenSecret || crypto.createHash('sha256').update(config.admin.password).digest('hex');
}
function sign(exp: number): string {
  return crypto.createHmac('sha256', secret()).update(String(exp)).digest('hex');
}
export function issueToken(ttlMs = 7 * 24 * 3600 * 1000): string {
  const exp = Date.now() + ttlMs;
  return `${exp}.${sign(exp)}`;
}
export function verifyAdminToken(token: string): boolean {
  const [expStr, mac] = (token || '').split('.');
  if (!expStr || !mac) return false;
  const exp = Number(expStr);
  if (!exp || Date.now() > exp) return false;
  const expected = sign(exp);
  if (mac.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(expected));
}

function adminAuth(req: Request, res: Response, next: NextFunction) {
  if (!config.admin.enabled) return res.status(503).json({ error: 'admin_disabled' });
  const h = req.header('authorization') ?? '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : req.header('x-admin-token') ?? '';
  if (!verifyAdminToken(token)) return res.status(401).json({ error: 'unauthorized' });
  next();
}

// Обёртка async-обработчиков (Express 4 сам не ловит reject).
const h =
  (fn: (req: Request, res: Response) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) =>
    Promise.resolve(fn(req, res)).catch(next);

const asTariff = (v: unknown): Tariff => (v === 'team' ? 'team' : 'personal');

// Калькулятор стоимости в рублях по текущим ценам (за 1000 токенов).
async function rubCalc(): Promise<(inTok: number, outTok: number) => number> {
  const inPrice = Number((await store.getSetting('price_input_per_1k')) ?? 0);
  const outPrice = Number((await store.getSetting('price_output_per_1k')) ?? 0);
  return (inTok, outTok) =>
    Math.round(((inTok / 1000) * inPrice + (outTok / 1000) * outPrice) * 100) / 100;
}
const slug = (v: unknown) =>
  String(v ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
// id из латиницы заголовка; если получился пустой/мусорный (напр. кириллица) — случайный.
function makeAgentId(idRaw: unknown, titleRaw: unknown): string {
  const fromInput = slug(idRaw || titleRaw);
  if (fromInput) return fromInput;
  return 'agent-' + crypto.randomBytes(3).toString('hex');
}

export const adminRouter = Router();

// --- Вход ---
adminRouter.post(
  '/login',
  h(async (req, res) => {
    if (!config.admin.enabled) return res.status(503).json({ error: 'admin_disabled' });
    const password = String(req.body?.password ?? '');
    const ok =
      password.length === config.admin.password.length &&
      crypto.timingSafeEqual(Buffer.from(password), Buffer.from(config.admin.password));
    if (!ok) return res.status(401).json({ error: 'bad_password' });
    res.json({ token: issueToken() });
  }),
);

// Всё ниже — только с валидным токеном
adminRouter.use(adminAuth);

// --- Агенты ---
adminRouter.get(
  '/agents',
  h(async (_req, res) => {
    res.json(await store.listAgents(true)); // включая выключенных
  }),
);

adminRouter.post(
  '/agents',
  h(async (req, res) => {
    const b = req.body ?? {};
    if (!String(b.title ?? '').trim()) return res.status(400).json({ error: 'no_title' });
    const id = makeAgentId(b.id, b.title);
    if (await store.getAgentConfig(id)) return res.status(409).json({ error: 'id_exists' });
    const agent: AgentConfig = {
      id,
      title: String(b.title ?? id),
      buttonLabel: String(b.buttonLabel ?? ''),
      tariff: asTariff(b.tariff),
      systemPrompt: String(b.systemPrompt ?? ''),
      knowledge: String(b.knowledge ?? ''),
      knowledgeRefs: [],
      model: b.model ? String(b.model) : undefined,
      folder: String(b.folder ?? '').trim(),
      enabled: b.enabled !== false,
      updatedAt: new Date().toISOString(),
    };
    res.json(await store.createAgent(agent));
  }),
);

adminRouter.put(
  '/agents/:id',
  h(async (req, res) => {
    const existing = await store.getAgentConfig(req.params.id);
    if (!existing) return res.status(404).json({ error: 'not_found' });
    const b = req.body ?? {};
    // Снимок прежней версии промпта/знаний — для отката
    await store.addAgentVersion(existing.id, existing.systemPrompt, existing.knowledge);
    const updated: AgentConfig = {
      ...existing,
      title: b.title !== undefined ? String(b.title) : existing.title,
      buttonLabel: b.buttonLabel !== undefined ? String(b.buttonLabel) : existing.buttonLabel,
      tariff: b.tariff !== undefined ? asTariff(b.tariff) : existing.tariff,
      systemPrompt: b.systemPrompt !== undefined ? String(b.systemPrompt) : existing.systemPrompt,
      knowledge: b.knowledge !== undefined ? String(b.knowledge) : existing.knowledge,
      model: b.model !== undefined ? (b.model ? String(b.model) : undefined) : existing.model,
      folder: b.folder !== undefined ? String(b.folder).trim() : existing.folder,
      enabled: b.enabled !== undefined ? b.enabled !== false : existing.enabled,
      updatedAt: new Date().toISOString(),
    };
    res.json(await store.updateAgent(updated));
  }),
);

adminRouter.delete(
  '/agents/:id',
  h(async (req, res) => {
    await store.deleteAgent(req.params.id);
    res.json({ ok: true });
  }),
);

adminRouter.get(
  '/agents/:id/versions',
  h(async (req, res) => {
    res.json(await store.listAgentVersions(req.params.id));
  }),
);

adminRouter.post(
  '/agents/:id/rollback/:versionId',
  h(async (req, res) => {
    const existing = await store.getAgentConfig(req.params.id);
    if (!existing) return res.status(404).json({ error: 'not_found' });
    const versions = await store.listAgentVersions(req.params.id);
    const v = versions.find((x) => x.id === Number(req.params.versionId));
    if (!v) return res.status(404).json({ error: 'version_not_found' });
    // Текущее состояние тоже сохраняем как версию, потом откатываемся
    await store.addAgentVersion(existing.id, existing.systemPrompt, existing.knowledge);
    res.json(
      await store.updateAgent({
        ...existing,
        systemPrompt: v.systemPrompt,
        knowledge: v.knowledge,
        updatedAt: new Date().toISOString(),
      }),
    );
  }),
);

// --- Общая база знаний ---
adminRouter.get(
  '/knowledge',
  h(async (_req, res) => {
    res.json({ global: (await store.getSetting('knowledge_global')) ?? '' });
  }),
);
adminRouter.put(
  '/knowledge',
  h(async (req, res) => {
    await store.setSetting('knowledge_global', String(req.body?.global ?? ''));
    res.json({ ok: true });
  }),
);

// --- Извлечение текста из файла для базы знаний (PDF/текстовые форматы) ---
// Принимает { name, type, dataBase64 }, возвращает { text } для вставки в знания.
adminRouter.post(
  '/extract',
  h(async (req, res) => {
    const b = req.body ?? {};
    const name = String(b.name ?? 'файл');
    const type = String(b.type ?? '');
    const b64 = String(b.dataBase64 ?? '').replace(/^data:[^;]+;base64,/, '');
    if (!b64) return res.status(400).json({ error: 'no_file' });
    const buf = Buffer.from(b64, 'base64');
    const ex = await extractFile(buf, type, name);
    if (ex.kind === 'text' && ex.text) return res.json({ text: ex.text, name });
    if (ex.kind === 'image') {
      return res.status(415).json({ error: 'image_unsupported' });
    }
    return res.status(415).json({ error: 'extract_failed', detail: ex.error ?? '' });
  }),
);

// --- Цены (рублей за 1000 токенов) ---
adminRouter.get(
  '/pricing',
  h(async (_req, res) => {
    res.json({
      inputPer1k: Number((await store.getSetting('price_input_per_1k')) ?? 0),
      outputPer1k: Number((await store.getSetting('price_output_per_1k')) ?? 0),
    });
  }),
);
adminRouter.put(
  '/pricing',
  h(async (req, res) => {
    await store.setSetting('price_input_per_1k', String(Number(req.body?.inputPer1k ?? 0)));
    await store.setSetting('price_output_per_1k', String(Number(req.body?.outputPer1k ?? 0)));
    res.json({ ok: true });
  }),
);

// --- Расход токенов (по агентам + итог + рубли) ---
adminRouter.get(
  '/usage',
  h(async (_req, res) => {
    const usage = await store.getAgentUsage();
    const agents = await store.listAgents(true);
    const titleById = new Map(agents.map((a) => [a.id, a.title]));
    const inPrice = Number((await store.getSetting('price_input_per_1k')) ?? 0);
    const outPrice = Number((await store.getSetting('price_output_per_1k')) ?? 0);
    const rub = (inTok: number, outTok: number) => (inTok / 1000) * inPrice + (outTok / 1000) * outPrice;
    const rows = usage.map((u) => ({
      agentId: u.agentId,
      title: titleById.get(u.agentId) ?? u.agentId,
      requests: u.requests,
      inputTokens: u.inputTokens,
      outputTokens: u.outputTokens,
      rubles: Math.round(rub(u.inputTokens, u.outputTokens) * 100) / 100,
    }));
    const total = rows.reduce(
      (acc, r) => ({
        requests: acc.requests + r.requests,
        inputTokens: acc.inputTokens + r.inputTokens,
        outputTokens: acc.outputTokens + r.outputTokens,
        rubles: Math.round((acc.rubles + r.rubles) * 100) / 100,
      }),
      { requests: 0, inputTokens: 0, outputTokens: 0, rubles: 0 },
    );
    res.json({ rows, total });
  }),
);

// --- Просмотр диалогов ---
adminRouter.get(
  '/users',
  h(async (_req, res) => {
    const users = await store.listUsers();
    res.json(users.map((u) => ({ telegramId: u.telegramId, name: u.name, email: u.gcEmail })));
  }),
);
adminRouter.get(
  '/users/:id/history',
  h(async (req, res) => {
    res.json(await store.getSharedHistory(Number(req.params.id)));
  }),
);

// Сводка по пользователю: токены (вход/выход) + число сообщений от каждой стороны.
const KICKOFF = 'Здравствуйте! Я готов начать — подскажите, с чего начать.';
adminRouter.get(
  '/users/:id/stats',
  h(async (req, res) => {
    const id = Number(req.params.id);
    const usage = await store.getUserUsageTotal(id);
    const history = await store.getSharedHistory(id);
    // Скрытое стартовое сообщение не считаем за реплику пользователя.
    const userMessages = history.filter((m) => m.role === 'user' && m.content !== KICKOFF).length;
    const agentMessages = history.filter((m) => m.role === 'assistant').length;

    // Разбивка по агентам: из диалогов пользователя (в каждом сообщении есть токены).
    const dialogs = await store.getUserDialogs(id);
    const agents = await store.listAgents(true);
    const titleById = new Map(agents.map((a) => [a.id, a.title]));
    const rub = await rubCalc();
    const byAgent = dialogs
      .map((d) => {
        let inTok = 0;
        let outTok = 0;
        let uMsg = 0;
        let aMsg = 0;
        for (const m of d.messages) {
          if (m.role === 'user') {
            if (m.content !== KICKOFF) uMsg += 1;
            inTok += m.tokens ?? 0;
          } else if (m.role === 'assistant') {
            aMsg += 1;
            outTok += m.tokens ?? 0;
          }
        }
        return {
          agentId: d.agentId,
          title: titleById.get(d.agentId) ?? d.agentId,
          inputTokens: inTok,
          outputTokens: outTok,
          userMessages: uMsg,
          agentMessages: aMsg,
          rubles: rub(inTok, outTok),
        };
      })
      .sort((a, b) => b.rubles - a.rubles);

    res.json({
      requests: usage.requests,
      inputTokens: usage.inputTokens,
      outputTokens: usage.outputTokens,
      userMessages,
      agentMessages,
      rubles: rub(usage.inputTokens, usage.outputTokens),
      byAgent,
    });
  }),
);

// --- Сравнение моделей: один и тот же вопрос разным моделям, рядом ---
// Прогоняет вопрос (опц. в контексте промпта агента) через список моделей
// параллельно и возвращает ответ + токены + стоимость + время по каждой.
adminRouter.post(
  '/compare',
  h(async (req, res) => {
    const b = req.body ?? {};
    const question = String(b.question ?? '').trim();
    if (!question) return res.status(400).json({ error: 'no_question' });
    const models: string[] = Array.isArray(b.models)
      ? [...new Set((b.models as unknown[]).map((m) => String(m).trim()).filter((m) => m.length > 0))]
      : [];
    if (!models.length) return res.status(400).json({ error: 'no_models' });
    if (models.length > 6) return res.status(400).json({ error: 'too_many_models' });

    // Опциональный контекст агента: его системный промпт + база знаний.
    let system = '';
    if (b.agentId) {
      const agent = await store.getAgentConfig(String(b.agentId));
      if (agent) {
        const parts = [agent.systemPrompt];
        const globalKnowledge = (await store.getSetting('knowledge_global')) ?? '';
        if (globalKnowledge.trim()) parts.push(`База знаний (общая):\n${globalKnowledge}`);
        if (agent.knowledge.trim()) parts.push(`База знаний (по теме):\n${agent.knowledge}`);
        system = parts.join('\n\n');
      }
    }
    const base: ChatMessage[] = system ? [{ role: 'system', content: system }] : [];
    const messages: ChatMessage[] = [...base, { role: 'user', content: question }];
    const rub = await rubCalc();

    const results = await Promise.all(
      models.map(async (model) => {
        const started = Date.now();
        try {
          const r = await chatComplete(messages, model);
          return {
            model,
            content: r.content,
            inputTokens: r.inputTokens,
            outputTokens: r.outputTokens,
            rubles: rub(r.inputTokens, r.outputTokens),
            ms: Date.now() - started,
          };
        } catch (e) {
          return { model, error: (e as Error).message, ms: Date.now() - started };
        }
      }),
    );
    res.json({ results });
  }),
);
