// Движко-независимый слой LLM. Сейчас — адаптер ProxyAPI (OpenAI-совместимый).
// Без ключа возвращает МОК-ответ, чтобы разрабатывать без расходов.
// Чтобы переключиться на VseGPT/AITunnel/Claude — меняется baseUrl/model, не код.
import { config } from '../config.js';
import type { ChatMessage } from '../types.js';

export interface LlmResult {
  content: string;
  inputTokens: number;
  outputTokens: number;
}

export async function chatComplete(
  messages: ChatMessage[],
  model?: string,
): Promise<LlmResult> {
  // МОК-режим: ключа нет
  if (!config.llm.enabled) {
    const lastUser = [...messages].reverse().find((m) => m.role === 'user');
    return {
      content:
        '[МОК-ответ LLM] Реальный ответ появится после подключения ProxyAPI.\n' +
        `Получено: «${lastUser?.content ?? ''}».`,
      inputTokens: roughTokens(messages.map((m) => m.content).join(' ')),
      outputTokens: 30,
    };
  }

  // Реальный вызов ProxyAPI (OpenAI Chat Completions)
  const res = await fetch(`${config.llm.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${config.llm.apiKey}`,
    },
    body: JSON.stringify({
      model: model ?? config.llm.model,
      messages: messages.map((m) => ({ role: m.role, content: m.content })),
      temperature: 0.7,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`LLM error ${res.status}: ${text}`);
  }

  const data = (await res.json()) as {
    choices: { message: { content: string } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number };
  };

  return {
    content: data.choices[0]?.message?.content ?? '',
    inputTokens: data.usage?.prompt_tokens ?? 0,
    outputTokens: data.usage?.completion_tokens ?? 0,
  };
}

// Грубая оценка токенов для мок-режима (≈4 символа на токен).
function roughTokens(text: string): number {
  return Math.ceil(text.length / 4);
}
