// Минимальный статический сервер для прода (без зависимостей).
// Отдаёт собранный Astro-сайт из ./dist. Слушает PORT (по умолчанию 3001),
// чтобы Cloudflare-туннель направлял сюда хостнейм portfolio.prokachkaprodazh.ru.
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { join, extname, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), 'dist');
const PORT = Number(process.env.PORT ?? 3001);

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.json': 'application/json; charset=utf-8',
};

async function resolve(urlPath) {
  // защита от выхода за пределы ROOT
  let p = normalize(decodeURIComponent(urlPath.split('?')[0])).replace(/^(\.\.[/\\])+/, '');
  let file = join(ROOT, p);
  try {
    const s = await stat(file);
    if (s.isDirectory()) file = join(file, 'index.html');
  } catch {
    // нет файла — отдаём index.html (для SPA-подобных путей)
    file = join(ROOT, 'index.html');
  }
  return file;
}

createServer(async (req, res) => {
  try {
    const file = await resolve(req.url || '/');
    const data = await readFile(file);
    res.writeHead(200, { 'content-type': TYPES[extname(file)] ?? 'application/octet-stream' });
    res.end(data);
  } catch {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }
}).listen(PORT, () => console.log(`Портфолио на http://localhost:${PORT} (dist: ${ROOT})`));
