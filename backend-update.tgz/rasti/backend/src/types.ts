// Общие типы бэкенда.

export type Tariff = 'personal' | 'team';

export interface User {
  telegramId: number;
  name: string;
  // Связка с Геткурсом
  gcEmail: string | null;
  gcUserId: string | null;
  // Доступ (источник истины — Геткурс, здесь актуальная копия)
  tariff: Tariff;
  accessActive: boolean;
  accessUntil: string | null; // ISO
}

// Профиль/анкета — фундамент памяти. Подставляется во всех агентов.
export interface Profile {
  telegramId: number;
  niche: string;        // ниша/сфера
  product: string;      // что продаёт
  audience: string;     // целевая аудитория
  avgCheck: string;     // средний чек
  notes: string;        // произвольные заметки/факты о бизнесе
  updatedAt: string;
}

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

// «Ветка» агента = тема. Один бот, N веток.
export interface AgentConfig {
  id: string;
  title: string;
  buttonLabel: string;
  tariff: Tariff;            // минимальный тариф
  systemPrompt: string;      // инструкция (перенос из Custom GPT Instructions)
  knowledgeRefs: string[];   // ссылки/идентификаторы файлов базы знаний (RAG) — задел
  model?: string;            // переопределение модели для этой ветки (гибрид)
}

// Запись истории диалога пользователя с конкретным агентом.
export interface DialogTurn {
  telegramId: number;
  agentId: string;
  messages: ChatMessage[]; // только user/assistant
  updatedAt: string;
}

// Смысловая выжимка длинной истории (сквозная память).
// summary — сжатые ключевые факты; coveredCount — сколько самых старых
// сообщений сквозной истории уже учтено в выжимке.
export interface MemorySummary {
  telegramId: number;
  summary: string;
  coveredCount: number;
}

// Учёт расходов/лимитов.
export interface UsageRecord {
  telegramId: number;
  date: string;            // YYYY-MM-DD
  requests: number;
  inputTokens: number;
  outputTokens: number;
}
