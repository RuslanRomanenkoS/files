// Постоянное хранилище на PostgreSQL. Подключается, когда задан DATABASE_URL.
// Схема создаётся автоматически при старте (init). Реализует тот же интерфейс
// Storage, что и MemoryStore, поэтому бизнес-логика не меняется.
import pg from 'pg';
import type { Storage } from './store.js';
import { newGkUser, seedToAgent } from './store.js';
import { agentSeed } from './mock/data.js';
import type {
  AdminRole,
  AdminUserAccount,
  AgentConfig,
  AgentUsage,
  AgentVersion,
  ChatMessage,
  DialogTurn,
  MemorySummary,
  Profile,
  UsageRecord,
  User,
} from './types.js';

const { Pool } = pg;

// Минимальный контракт клиента БД: и pg.Pool, и совместимые движки (для тестов)
// предоставляют query(text, params) -> { rows }.
export interface Queryable {
  query<R extends Record<string, unknown> = Record<string, unknown>>(
    text: string,
    params?: unknown[],
  ): Promise<{ rows: R[] }>;
}

const today = () => new Date().toISOString().slice(0, 10);

// pg отдаёт BIGINT строкой — приводим к number (id умещается в безопасное целое).
type UserRow = {
  telegram_id: string;
  name: string;
  gc_email: string | null;
  gc_user_id: string | null;
  tariff: string;
  access_active: boolean;
  access_until: string | null;
};

function rowToUser(r: UserRow): User {
  return {
    telegramId: Number(r.telegram_id),
    name: r.name,
    gcEmail: r.gc_email,
    gcUserId: r.gc_user_id,
    tariff: r.tariff === 'team' ? 'team' : 'personal',
    accessActive: r.access_active,
    accessUntil: r.access_until,
  };
}

export class PostgresStore implements Storage {
  private pool: Queryable;

  // url — строка подключения (прод). Для тестов можно передать готовый клиент.
  constructor(url: string, client?: Queryable) {
    this.pool = client ?? (new Pool({ connectionString: url }) as Queryable);
  }

  async init() {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        telegram_id   BIGINT PRIMARY KEY,
        name          TEXT NOT NULL,
        gc_email      TEXT,
        gc_user_id    TEXT,
        tariff        TEXT NOT NULL,
        access_active BOOLEAN NOT NULL DEFAULT TRUE,
        access_until  TEXT
      );
      CREATE INDEX IF NOT EXISTS users_gc_email_idx ON users (lower(gc_email));

      CREATE TABLE IF NOT EXISTS profiles (
        telegram_id BIGINT PRIMARY KEY,
        niche       TEXT NOT NULL DEFAULT '',
        product     TEXT NOT NULL DEFAULT '',
        audience    TEXT NOT NULL DEFAULT '',
        avg_check   TEXT NOT NULL DEFAULT '',
        notes       TEXT NOT NULL DEFAULT '',
        updated_at  TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS dialogs (
        telegram_id BIGINT NOT NULL,
        agent_id    TEXT NOT NULL,
        messages    JSONB NOT NULL DEFAULT '[]',
        updated_at  TEXT NOT NULL,
        PRIMARY KEY (telegram_id, agent_id)
      );

      CREATE TABLE IF NOT EXISTS shared_history (
        telegram_id BIGINT PRIMARY KEY,
        messages    JSONB NOT NULL DEFAULT '[]'
      );

      CREATE TABLE IF NOT EXISTS memory_summary (
        telegram_id   BIGINT PRIMARY KEY,
        summary       TEXT NOT NULL DEFAULT '',
        covered_count INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS usage (
        telegram_id   BIGINT NOT NULL,
        date          TEXT NOT NULL,
        requests      INTEGER NOT NULL DEFAULT 0,
        input_tokens  INTEGER NOT NULL DEFAULT 0,
        output_tokens INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (telegram_id, date)
      );

      CREATE TABLE IF NOT EXISTS agents (
        id            TEXT PRIMARY KEY,
        title         TEXT NOT NULL,
        button_label  TEXT NOT NULL DEFAULT '',
        tariff        TEXT NOT NULL DEFAULT 'personal',
        system_prompt TEXT NOT NULL DEFAULT '',
        knowledge     TEXT NOT NULL DEFAULT '',
        model         TEXT,
        folder        TEXT NOT NULL DEFAULT '',
        folders       JSONB NOT NULL DEFAULT '[]',
        comment       TEXT NOT NULL DEFAULT '',
        enabled       BOOLEAN NOT NULL DEFAULT TRUE,
        updated_at    TEXT NOT NULL
      );
      -- Миграции для существующих БД.
      ALTER TABLE agents ADD COLUMN IF NOT EXISTS folder TEXT NOT NULL DEFAULT '';
      ALTER TABLE agents ADD COLUMN IF NOT EXISTS folders JSONB NOT NULL DEFAULT '[]';
      ALTER TABLE agents ADD COLUMN IF NOT EXISTS comment TEXT NOT NULL DEFAULT '';
      -- Перенос старого одиночного folder в новый массив folders (один раз).
      UPDATE agents SET folders = jsonb_build_array(folder)
        WHERE folder <> '' AND folders = '[]'::jsonb;

      CREATE TABLE IF NOT EXISTS agent_versions (
        id            SERIAL PRIMARY KEY,
        agent_id      TEXT NOT NULL,
        system_prompt TEXT NOT NULL DEFAULT '',
        knowledge     TEXT NOT NULL DEFAULT '',
        created_at    TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS settings (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL DEFAULT ''
      );

      CREATE TABLE IF NOT EXISTS usage_by_agent (
        agent_id      TEXT PRIMARY KEY,
        requests      INTEGER NOT NULL DEFAULT 0,
        input_tokens  INTEGER NOT NULL DEFAULT 0,
        output_tokens INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS admin_users (
        id            SERIAL PRIMARY KEY,
        username      TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role          TEXT NOT NULL DEFAULT 'admin',
        created_at    TEXT NOT NULL
      );
    `);

    // Засев агентов по умолчанию, если таблица пуста.
    const { rows } = await this.pool.query<{ n: string }>('SELECT count(*)::text AS n FROM agents');
    if (rows[0] && Number(rows[0].n) === 0) {
      for (const s of agentSeed) await this.createAgent(seedToAgent(s));
    }

    console.log('  Хранилище: PostgreSQL (постоянное)');
  }

  // --- Пользователи / доступ ---
  async getUser(telegramId: number) {
    const { rows } = await this.pool.query<UserRow>('SELECT * FROM users WHERE telegram_id = $1', [telegramId]);
    return rows[0] ? rowToUser(rows[0]) : undefined;
  }

  async upsertUser(user: User) {
    await this.pool.query(
      `INSERT INTO users (telegram_id, name, gc_email, gc_user_id, tariff, access_active, access_until)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (telegram_id) DO UPDATE SET
         name = EXCLUDED.name,
         gc_email = EXCLUDED.gc_email,
         gc_user_id = EXCLUDED.gc_user_id,
         tariff = EXCLUDED.tariff,
         access_active = EXCLUDED.access_active,
         access_until = EXCLUDED.access_until`,
      [user.telegramId, user.name, user.gcEmail, user.gcUserId, user.tariff, user.accessActive, user.accessUntil],
    );
    return user;
  }

  async getUserByEmail(email: string) {
    const { rows } = await this.pool.query<UserRow>(
      'SELECT * FROM users WHERE lower(gc_email) = lower($1) LIMIT 1',
      [email.trim()],
    );
    return rows[0] ? rowToUser(rows[0]) : undefined;
  }

  async upsertGkUser(email: string, name?: string) {
    const existing = await this.getUserByEmail(email);
    if (existing) return existing;
    const user = newGkUser(email, name);
    await this.upsertUser(user);
    return user;
  }

  async listUsers() {
    const { rows } = await this.pool.query<UserRow>('SELECT * FROM users ORDER BY name');
    return rows.map(rowToUser);
  }

  async setAccessByEmail(
    email: string,
    patch: Partial<Pick<User, 'tariff' | 'accessActive' | 'accessUntil' | 'gcUserId'>>,
  ) {
    const user = await this.getUserByEmail(email);
    if (!user) return undefined;
    const updated: User = { ...user, ...patch };
    await this.upsertUser(updated);
    return updated;
  }

  // --- Профиль ---
  async getProfile(telegramId: number) {
    const { rows } = await this.pool.query<{
      telegram_id: string;
      niche: string;
      product: string;
      audience: string;
      avg_check: string;
      notes: string;
      updated_at: string;
    }>(
      'SELECT telegram_id, niche, product, audience, avg_check, notes, updated_at FROM profiles WHERE telegram_id = $1',
      [telegramId],
    );
    const r = rows[0];
    if (!r) return undefined;
    return {
      telegramId: Number(r.telegram_id),
      niche: r.niche,
      product: r.product,
      audience: r.audience,
      avgCheck: r.avg_check,
      notes: r.notes,
      updatedAt: r.updated_at,
    } satisfies Profile;
  }

  async saveProfile(profile: Profile) {
    await this.pool.query(
      `INSERT INTO profiles (telegram_id, niche, product, audience, avg_check, notes, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (telegram_id) DO UPDATE SET
         niche = EXCLUDED.niche,
         product = EXCLUDED.product,
         audience = EXCLUDED.audience,
         avg_check = EXCLUDED.avg_check,
         notes = EXCLUDED.notes,
         updated_at = EXCLUDED.updated_at`,
      [profile.telegramId, profile.niche, profile.product, profile.audience, profile.avgCheck, profile.notes, profile.updatedAt],
    );
    return profile;
  }

  // --- История по агенту ---
  async getDialog(telegramId: number, agentId: string) {
    const { rows } = await this.pool.query<{ messages: ChatMessage[]; updated_at: string }>(
      'SELECT messages, updated_at FROM dialogs WHERE telegram_id = $1 AND agent_id = $2',
      [telegramId, agentId],
    );
    const r = rows[0];
    if (!r) return undefined;
    return {
      telegramId,
      agentId,
      messages: r.messages,
      updatedAt: r.updated_at,
    } satisfies DialogTurn;
  }

  async saveDialog(turn: DialogTurn) {
    await this.pool.query(
      `INSERT INTO dialogs (telegram_id, agent_id, messages, updated_at)
       VALUES ($1, $2, $3::jsonb, $4)
       ON CONFLICT (telegram_id, agent_id) DO UPDATE SET
         messages = EXCLUDED.messages,
         updated_at = EXCLUDED.updated_at`,
      [turn.telegramId, turn.agentId, JSON.stringify(turn.messages), turn.updatedAt],
    );
    return turn;
  }

  async getUserDialogs(telegramId: number) {
    const { rows } = await this.pool.query<{ agent_id: string; messages: ChatMessage[]; updated_at: string }>(
      'SELECT agent_id, messages, updated_at FROM dialogs WHERE telegram_id = $1',
      [telegramId],
    );
    return rows.map((r) => ({
      telegramId,
      agentId: r.agent_id,
      messages: r.messages,
      updatedAt: r.updated_at,
    })) satisfies DialogTurn[];
  }

  // --- Сквозная память ---
  async getSharedHistory(telegramId: number) {
    const { rows } = await this.pool.query<{ messages: ChatMessage[] }>(
      'SELECT messages FROM shared_history WHERE telegram_id = $1',
      [telegramId],
    );
    return rows[0] ? rows[0].messages : [];
  }

  async appendShared(telegramId: number, userMsg: ChatMessage, assistantMsg: ChatMessage) {
    await this.pool.query(
      `INSERT INTO shared_history (telegram_id, messages)
       VALUES ($1, $2::jsonb)
       ON CONFLICT (telegram_id) DO UPDATE SET
         messages = shared_history.messages || EXCLUDED.messages`,
      [telegramId, JSON.stringify([userMsg, assistantMsg])],
    );
  }

  // --- Смысловая выжимка ---
  async getSummary(telegramId: number) {
    const { rows } = await this.pool.query<{ summary: string; covered_count: number }>(
      'SELECT summary, covered_count FROM memory_summary WHERE telegram_id = $1',
      [telegramId],
    );
    const r = rows[0];
    if (!r) return undefined;
    return { telegramId, summary: r.summary, coveredCount: r.covered_count } satisfies MemorySummary;
  }

  async saveSummary(telegramId: number, summary: string, coveredCount: number) {
    await this.pool.query(
      `INSERT INTO memory_summary (telegram_id, summary, covered_count)
       VALUES ($1, $2, $3)
       ON CONFLICT (telegram_id) DO UPDATE SET
         summary = EXCLUDED.summary,
         covered_count = EXCLUDED.covered_count`,
      [telegramId, summary, coveredCount],
    );
  }

  // --- Учёт расходов ---
  async getUsageToday(telegramId: number) {
    const { rows } = await this.pool.query<{
      requests: number;
      input_tokens: number;
      output_tokens: number;
    }>(
      'SELECT requests, input_tokens, output_tokens FROM usage WHERE telegram_id = $1 AND date = $2',
      [telegramId, today()],
    );
    const r = rows[0];
    return {
      telegramId,
      date: today(),
      requests: r ? r.requests : 0,
      inputTokens: r ? r.input_tokens : 0,
      outputTokens: r ? r.output_tokens : 0,
    } satisfies UsageRecord;
  }

  async addUsage(telegramId: number, inputTokens: number, outputTokens: number) {
    await this.pool.query(
      `INSERT INTO usage (telegram_id, date, requests, input_tokens, output_tokens)
       VALUES ($1, $2, 1, $3, $4)
       ON CONFLICT (telegram_id, date) DO UPDATE SET
         requests = usage.requests + 1,
         input_tokens = usage.input_tokens + EXCLUDED.input_tokens,
         output_tokens = usage.output_tokens + EXCLUDED.output_tokens`,
      [telegramId, today(), inputTokens, outputTokens],
    );
  }

  async getUserUsageTotal(telegramId: number) {
    const { rows } = await this.pool.query<{ requests: string; input_tokens: string; output_tokens: string }>(
      `SELECT COALESCE(SUM(requests),0)::text AS requests,
              COALESCE(SUM(input_tokens),0)::text AS input_tokens,
              COALESCE(SUM(output_tokens),0)::text AS output_tokens
       FROM usage WHERE telegram_id = $1`,
      [telegramId],
    );
    const r = rows[0];
    return {
      requests: Number(r?.requests ?? 0),
      inputTokens: Number(r?.input_tokens ?? 0),
      outputTokens: Number(r?.output_tokens ?? 0),
    };
  }

  // --- Агенты ---
  private async upsertAgentRow(a: AgentConfig) {
    await this.pool.query(
      `INSERT INTO agents (id, title, button_label, tariff, system_prompt, knowledge, model, folders, comment, enabled, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, $9, $10, $11)
       ON CONFLICT (id) DO UPDATE SET
         title = EXCLUDED.title,
         button_label = EXCLUDED.button_label,
         tariff = EXCLUDED.tariff,
         system_prompt = EXCLUDED.system_prompt,
         knowledge = EXCLUDED.knowledge,
         model = EXCLUDED.model,
         folders = EXCLUDED.folders,
         comment = EXCLUDED.comment,
         enabled = EXCLUDED.enabled,
         updated_at = EXCLUDED.updated_at`,
      [
        a.id,
        a.title,
        a.buttonLabel,
        a.tariff,
        a.systemPrompt,
        a.knowledge,
        a.model ?? null,
        JSON.stringify(a.folders ?? []),
        a.comment ?? '',
        a.enabled,
        a.updatedAt,
      ],
    );
    return a;
  }

  async listAgents(includeDisabled = false) {
    const { rows } = await this.pool.query<AgentRow>(
      `SELECT * FROM agents ${includeDisabled ? '' : 'WHERE enabled = TRUE'} ORDER BY title`,
    );
    return rows.map(rowToAgent);
  }
  async getAgentConfig(id: string) {
    const { rows } = await this.pool.query<AgentRow>('SELECT * FROM agents WHERE id = $1', [id]);
    return rows[0] ? rowToAgent(rows[0]) : undefined;
  }
  async createAgent(agent: AgentConfig) {
    return this.upsertAgentRow(agent);
  }
  async updateAgent(agent: AgentConfig) {
    return this.upsertAgentRow(agent);
  }
  async deleteAgent(id: string) {
    await this.pool.query('DELETE FROM agent_versions WHERE agent_id = $1', [id]);
    await this.pool.query('DELETE FROM usage_by_agent WHERE agent_id = $1', [id]);
    await this.pool.query('DELETE FROM agents WHERE id = $1', [id]);
  }
  async listAgentVersions(agentId: string) {
    const { rows } = await this.pool.query<{
      id: number;
      agent_id: string;
      system_prompt: string;
      knowledge: string;
      created_at: string;
    }>('SELECT * FROM agent_versions WHERE agent_id = $1 ORDER BY id DESC', [agentId]);
    return rows.map((r) => ({
      id: r.id,
      agentId: r.agent_id,
      systemPrompt: r.system_prompt,
      knowledge: r.knowledge,
      createdAt: r.created_at,
    })) satisfies AgentVersion[];
  }
  async addAgentVersion(agentId: string, systemPrompt: string, knowledge: string) {
    await this.pool.query(
      'INSERT INTO agent_versions (agent_id, system_prompt, knowledge, created_at) VALUES ($1, $2, $3, $4)',
      [agentId, systemPrompt, knowledge, new Date().toISOString()],
    );
  }

  // --- Настройки ---
  async getSetting(key: string) {
    const { rows } = await this.pool.query<{ value: string }>('SELECT value FROM settings WHERE key = $1', [key]);
    return rows[0]?.value;
  }
  async setSetting(key: string, value: string) {
    await this.pool.query(
      `INSERT INTO settings (key, value) VALUES ($1, $2)
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
      [key, value],
    );
  }

  // --- Расход по агентам ---
  async addAgentUsage(agentId: string, inputTokens: number, outputTokens: number) {
    await this.pool.query(
      `INSERT INTO usage_by_agent (agent_id, requests, input_tokens, output_tokens)
       VALUES ($1, 1, $2, $3)
       ON CONFLICT (agent_id) DO UPDATE SET
         requests = usage_by_agent.requests + 1,
         input_tokens = usage_by_agent.input_tokens + EXCLUDED.input_tokens,
         output_tokens = usage_by_agent.output_tokens + EXCLUDED.output_tokens`,
      [agentId, inputTokens, outputTokens],
    );
  }
  async getAgentUsage() {
    const { rows } = await this.pool.query<{
      agent_id: string;
      requests: number;
      input_tokens: number;
      output_tokens: number;
    }>('SELECT * FROM usage_by_agent');
    return rows.map((r) => ({
      agentId: r.agent_id,
      requests: r.requests,
      inputTokens: r.input_tokens,
      outputTokens: r.output_tokens,
    })) satisfies AgentUsage[];
  }

  // --- Учётные записи админов ---
  async listAdminUsers() {
    const { rows } = await this.pool.query<AdminUserRow>('SELECT * FROM admin_users ORDER BY username');
    return rows.map(rowToAdminUser);
  }
  async getAdminUserById(id: number) {
    const { rows } = await this.pool.query<AdminUserRow>('SELECT * FROM admin_users WHERE id = $1', [id]);
    return rows[0] ? rowToAdminUser(rows[0]) : undefined;
  }
  async getAdminUserByUsername(username: string) {
    const { rows } = await this.pool.query<AdminUserRow>(
      'SELECT * FROM admin_users WHERE lower(username) = lower($1) LIMIT 1',
      [username.trim()],
    );
    return rows[0] ? rowToAdminUser(rows[0]) : undefined;
  }
  async createAdminUser(username: string, passwordHash: string, role: AdminRole) {
    const { rows } = await this.pool.query<AdminUserRow>(
      `INSERT INTO admin_users (username, password_hash, role, created_at)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [username, passwordHash, role, new Date().toISOString()],
    );
    return rowToAdminUser(rows[0]);
  }
  async updateAdminUser(id: number, patch: Partial<Pick<AdminUserAccount, 'role' | 'passwordHash'>>) {
    const existing = await this.getAdminUserById(id);
    if (!existing) return undefined;
    const role = patch.role ?? existing.role;
    const passwordHash = patch.passwordHash ?? existing.passwordHash;
    const { rows } = await this.pool.query<AdminUserRow>(
      'UPDATE admin_users SET role = $2, password_hash = $3 WHERE id = $1 RETURNING *',
      [id, role, passwordHash],
    );
    return rows[0] ? rowToAdminUser(rows[0]) : undefined;
  }
  async deleteAdminUser(id: number) {
    await this.pool.query('DELETE FROM admin_users WHERE id = $1', [id]);
  }
}

type AdminUserRow = {
  id: number;
  username: string;
  password_hash: string;
  role: string;
  created_at: string;
};
function rowToAdminUser(r: AdminUserRow): AdminUserAccount {
  return {
    id: r.id,
    username: r.username,
    passwordHash: r.password_hash,
    role: r.role === 'super_admin' || r.role === 'viewer' ? r.role : 'admin',
    createdAt: r.created_at,
  };
}

type AgentRow = {
  id: string;
  title: string;
  button_label: string;
  tariff: string;
  system_prompt: string;
  knowledge: string;
  model: string | null;
  folders: string[] | null;
  comment: string | null;
  enabled: boolean;
  updated_at: string;
};

function rowToAgent(r: AgentRow): AgentConfig {
  return {
    id: r.id,
    title: r.title,
    buttonLabel: r.button_label,
    tariff: r.tariff === 'team' ? 'team' : 'personal',
    systemPrompt: r.system_prompt,
    knowledge: r.knowledge,
    knowledgeRefs: [],
    model: r.model ?? undefined,
    folders: r.folders ?? [],
    comment: r.comment ?? '',
    enabled: r.enabled,
    updatedAt: r.updated_at,
  };
}
