// Хранилище за асинхронным интерфейсом Storage.
// Две реализации: MemoryStore (ОЗУ, для локальной разработки без БД) и
// PostgresStore (постоянное хранение, прод). Выбор — по наличию DATABASE_URL.
// Бизнес-логика работает только через этот интерфейс и не знает, что под ним.

import type { ChatMessage, DialogTurn, MemorySummary, Profile, UsageRecord, User } from './types.js';
import { demoUsers } from './mock/data.js';
import { emailToId } from './ids.js';
import { config } from './config.js';

const today = () => new Date().toISOString().slice(0, 10);

export interface Storage {
  init(): Promise<void>;

  // Пользователи / доступ
  getUser(telegramId: number): Promise<User | undefined>;
  upsertUser(user: User): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  upsertGkUser(email: string, name?: string): Promise<User>;
  setAccessByEmail(
    email: string,
    patch: Partial<Pick<User, 'tariff' | 'accessActive' | 'accessUntil' | 'gcUserId'>>,
  ): Promise<User | undefined>;

  // Профиль (память)
  getProfile(telegramId: number): Promise<Profile | undefined>;
  saveProfile(profile: Profile): Promise<Profile>;

  // История по агенту (для треда в интерфейсе)
  getDialog(telegramId: number, agentId: string): Promise<DialogTurn | undefined>;
  saveDialog(turn: DialogTurn): Promise<DialogTurn>;

  // Сквозная память (все агенты вместе)
  getSharedHistory(telegramId: number): Promise<ChatMessage[]>;
  appendShared(telegramId: number, userMsg: ChatMessage, assistantMsg: ChatMessage): Promise<void>;

  // Смысловая выжимка длинной истории
  getSummary(telegramId: number): Promise<MemorySummary | undefined>;
  saveSummary(telegramId: number, summary: string, coveredCount: number): Promise<void>;

  // Учёт расходов
  getUsageToday(telegramId: number): Promise<UsageRecord>;
  addUsage(telegramId: number, inputTokens: number, outputTokens: number): Promise<void>;
}

// Новый пользователь Геткурса: доступ контролирует сам ГК (виджет встроен в урок),
// поэтому любой открывший виджет считается имеющим доступ; tariff=team — видны все агенты.
export function newGkUser(email: string, name?: string): User {
  return {
    telegramId: emailToId(email),
    name: name || email,
    gcEmail: email,
    gcUserId: null,
    tariff: 'team',
    accessActive: true,
    accessUntil: null,
  };
}

// --- Реализация в памяти (dev / без БД) ---
class MemoryStore implements Storage {
  private users = new Map<number, User>(demoUsers.map((u) => [u.telegramId, u]));
  private profiles = new Map<number, Profile>();
  private dialogs = new Map<string, DialogTurn>(); // ключ: `${telegramId}:${agentId}`
  private shared = new Map<number, ChatMessage[]>();
  private summaries = new Map<number, MemorySummary>();
  private usage = new Map<string, UsageRecord>(); // ключ: `${telegramId}:${date}`

  async init() {
    /* ничего не требуется */
  }

  async getUser(telegramId: number) {
    return this.users.get(telegramId);
  }
  async upsertUser(user: User) {
    this.users.set(user.telegramId, user);
    return user;
  }
  async getUserByEmail(email: string) {
    const e = email.toLowerCase().trim();
    for (const u of this.users.values()) if (u.gcEmail?.toLowerCase() === e) return u;
    return undefined;
  }
  async upsertGkUser(email: string, name?: string) {
    const existing = await this.getUserByEmail(email);
    if (existing) return existing;
    const user = newGkUser(email, name);
    this.users.set(user.telegramId, user);
    return user;
  }
  async setAccessByEmail(
    email: string,
    patch: Partial<Pick<User, 'tariff' | 'accessActive' | 'accessUntil' | 'gcUserId'>>,
  ) {
    for (const u of this.users.values()) {
      if (u.gcEmail?.toLowerCase() === email.toLowerCase()) {
        Object.assign(u, patch);
        return u;
      }
    }
    return undefined;
  }

  async getProfile(telegramId: number) {
    return this.profiles.get(telegramId);
  }
  async saveProfile(profile: Profile) {
    this.profiles.set(profile.telegramId, profile);
    return profile;
  }

  async getDialog(telegramId: number, agentId: string) {
    return this.dialogs.get(`${telegramId}:${agentId}`);
  }
  async saveDialog(turn: DialogTurn) {
    this.dialogs.set(`${turn.telegramId}:${turn.agentId}`, turn);
    return turn;
  }

  async getSharedHistory(telegramId: number) {
    return this.shared.get(telegramId) ?? [];
  }
  async appendShared(telegramId: number, userMsg: ChatMessage, assistantMsg: ChatMessage) {
    const arr = this.shared.get(telegramId) ?? [];
    arr.push(userMsg, assistantMsg);
    this.shared.set(telegramId, arr);
  }

  async getSummary(telegramId: number) {
    return this.summaries.get(telegramId);
  }
  async saveSummary(telegramId: number, summary: string, coveredCount: number) {
    this.summaries.set(telegramId, { telegramId, summary, coveredCount });
  }

  async getUsageToday(telegramId: number) {
    const key = `${telegramId}:${today()}`;
    let rec = this.usage.get(key);
    if (!rec) {
      rec = { telegramId, date: today(), requests: 0, inputTokens: 0, outputTokens: 0 };
      this.usage.set(key, rec);
    }
    return rec;
  }
  async addUsage(telegramId: number, inputTokens: number, outputTokens: number) {
    const rec = await this.getUsageToday(telegramId);
    rec.requests += 1;
    rec.inputTokens += inputTokens;
    rec.outputTokens += outputTokens;
  }
}

// PostgresStore грузим лениво, чтобы 'pg' не требовался при работе в памяти.
async function createStore(): Promise<Storage> {
  if (config.database.url) {
    const { PostgresStore } = await import('./store.postgres.js');
    return new PostgresStore(config.database.url);
  }
  return new MemoryStore();
}

// Единый экземпляр. initStore() вызывается один раз при старте процесса.
export let store: Storage = new MemoryStore();

export async function initStore(): Promise<void> {
  store = await createStore();
  await store.init();
}
