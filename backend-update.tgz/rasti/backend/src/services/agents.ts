// Реестр и роутер агентов («один бот — N веток»).
import { agents } from '../mock/data.js';
import type { AgentConfig } from '../types.js';

export function listAgents(): AgentConfig[] {
  return agents;
}

export function getAgent(agentId: string): AgentConfig | undefined {
  return agents.find((a) => a.id === agentId);
}

// Публичное представление агента (без системного промпта — его клиенту знать не нужно).
export function publicAgent(a: AgentConfig) {
  return { id: a.id, title: a.title, buttonLabel: a.buttonLabel, tariff: a.tariff };
}
