// Админ-панель: вход по логину+паролю на каждого админа, три роли (viewer/admin/
// super_admin) + подписанный сессионный токен. Все маршруты под /api/admin.
// Логин открыт, остальное защищено adminAuth (+ requireRole для записи/доступов).
import crypto from 'node:crypto';
import { Router, type Request, type Response, type NextFunction } from 'express';
import { config } from './config.js';
import { store } from './store.js';
import { chatComplete } from './services/llm.js';
import { extractFile } from './services/files.js';
import type { AdminRole, AgentConfig, ChatMessage, Tariff } from './types.js';

// --- Пароли: pbkdf2 с солью, формат хранения "saltHex:hashHex" ---
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100_000, 32, 'sha256').toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const candidate = crypto.pbkdf2Sync(password, salt, 100_000, 32, 'sha256').toString('hex');
  return candidate.length === hash.length && crypto.timingSafeEqual(Buffer.from(candidate), Buffer.from(hash));
}

// Бутстрап первого супер-админа из .env (ADMIN_PASSWORD), если в БД ещё нет ни
// одного админ-аккаунта — на случай, если все супер-админы потеряли доступ.
export async function bootstrapAdminUsers(): Promise<void> {
  if (!config.admin.password) return;
  const existing = await store.listAdminUsers();
  if (existing.length > 0) return;
  await store.createAdminUser('admin', hashPassword(config.admin.password), 'super_admin');
  console.log('  Admin: создан стартовый супер-админ "admin" (пароль из ADMIN_PASSWORD)');
}

// --- Токен сессии (HMAC, со сроком жизни, несёт id/роль пользователя) ---
interface TokenPayload {
  id: number;
  username: string;
  role: AdminRole;
  exp: number;
}
function secret(): string {
  return config.admin.tokenSecret || crypto.createHash('sha256').update(config.admin.password || 'rasti').digest('hex');
}
function sign(payloadB64: string): string {
  return crypto.createHmac('sha256', secret()).update(payloadB64).digest('hex');
}
export function issueToken(user: { id: number; username: string; role: AdminRole }, ttlMs = 7 * 24 * 3600 * 1000): string {
  const payload: TokenPayload = { id: user.id, username: user.username, role: user.role, exp: Date.now() + ttlMs };
  const payloadB64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return `${payloadB64}.${sign(payloadB64)}`;
}
export function verifyAdminToken(token: string): TokenPayload | null {
  const [payloadB64, mac] = (token || '').split('.');
  if (!payloadB64 || !mac) return null;
  const expected = sign(payloadB64);
  if (mac.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(expected))) return null;
  try {
    const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString()) as TokenPayload;
    if (!payload.exp || Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

const ROLE_RANK: Record<AdminRole, number> = { viewer: 0, admin: 1, super_admin: 2 };

declare module 'express-serve-static-core' {
  interface Request {
    adminUser?: TokenPayload;
  }
}

function adminAuth(req: Request, res: Response, next: NextFunction) {
  if (!config.admin.enabled) return res.status(503).json({ error: 'admin_disabled' });
  const h = req.header('authorization') ?? '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : req.header('x-admin-token') ?? '';
  const payload = verifyAdminToken(token);
  if (!payload) return res.status(401).json({ error: 'unauthorized' });
  req.adminUser = payload;
  next();
}

// Требует минимум указанную роль (viewer < admin < super_admin).
function requireRole(min: AdminRole) {
  return (req: Request, res: Response, next: NextFunction) => {
    const role = req.adminUser?.role ?? 'viewer';
    if (ROLE_RANK[role] < ROLE_RANK[min]) return res.status(403).json({ error: 'forbidden' });
    next();
  };
}

// Обёртка async-обработчиков (Express 4 сам не ловит reject).
const h =
  (fn: (req: Request, res: Response) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) =>
    Promise.resolve(fn(req, res)).catch(next);

const asTariff = (v: unknown): Tariff => (v === 'team' ? 'team' : 'personal');

// Калькулятор стоимости в рублях по текущим ценам (за 1000 токенов).
async function rubCalc(): Promise<(inTok: number, outTok: number) => number> {
  const inPrice = Number((await store.getSetting('price_input_per_1k')) ?? 0);
  const outPrice = Number((await store.getSetting('price_output_per_1k')) ?? 0);
  return (inTok, outTok) =>
    Math.round(((inTok / 1000) * inPrice + (outTok / 1000) * outPrice) * 100) / 100;
}
const slug = (v: unknown) =>
  String(v ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
// id из латиницы заголовка; если получился пустой/мусорный (напр. кириллица) — случайный.
function makeAgentId(idRaw: unknown, titleRaw: unknown): string {
  const fromInput = slug(idRaw || titleRaw);
  if (fromInput) return fromInput;
  return 'agent-' + crypto.randomBytes(3).toString('hex');
}
const asFolders = (v: unknown): string[] =>
  Array.isArray(v)
    ? [...new Set((v as unknown[]).map((x) => String(x).trim()).filter(Boolean))]
    : [];

// Список папок (для подсказок в редакторе), храним отдельно — чтобы можно было
// создать пустую папку и видеть её, даже если в неё пока не добавлен ни один агент.
async function getFoldersList(): Promise<string[]> {
  const raw = (await store.getSetting('folders_list')) ?? '[]';
  try {
    const list = JSON.parse(raw) as unknown[];
    return Array.isArray(list) ? list.map((x) => String(x)) : [];
  } catch {
    return [];
  }
}
async function setFoldersList(list: string[]): Promise<void> {
  await store.setSetting('folders_list', JSON.stringify([...new Set(list)]));
}

export const adminRouter = Router();

// --- Вход (логин + пароль на каждого админа) ---
adminRouter.post(
  '/login',
  h(async (req, res) => {
    if (!config.admin.enabled) return res.status(503).json({ error: 'admin_disabled' });
    const username = String(req.body?.username ?? '').trim();
    const password = String(req.body?.password ?? '');
    const user = await store.getAdminUserByUsername(username);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return res.status(401).json({ error: 'bad_credentials' });
    }
    res.json({ token: issueToken(user), username: user.username, role: user.role });
  }),
);

// Всё ниже — только с валидным токеном
adminRouter.use(adminAuth);

// --- Агенты ---
adminRouter.get(
  '/agents',
  h(async (_req, res) => {
    res.json(await store.listAgents(true)); // включая выключенных
  }),
);

adminRouter.post(
  '/agents',
  requireRole('admin'),
  h(async (req, res) => {
    const b = req.body ?? {};
    if (!String(b.title ?? '').trim()) return res.status(400).json({ error: 'no_title' });
    const id = makeAgentId(b.id, b.title);
    if (await store.getAgentConfig(id)) return res.status(409).json({ error: 'id_exists' });
    const agent: AgentConfig = {
      id,
      title: String(b.title ?? id),
      buttonLabel: String(b.buttonLabel ?? ''),
      tariff: asTariff(b.tariff),
      systemPrompt: String(b.systemPrompt ?? ''),
      knowledge: String(b.knowledge ?? ''),
      knowledgeRefs: [],
      model: b.model ? String(b.model) : undefined,
      folders: asFolders(b.folders),
      comment: String(b.comment ?? ''),
      enabled: b.enabled !== false,
      updatedAt: new Date().toISOString(),
    };
    res.json(await store.createAgent(agent));
  }),
);

adminRouter.put(
  '/agents/:id',
  requireRole('admin'),
  h(async (req, res) => {
    const existing = await store.getAgentConfig(req.params.id);
    if (!existing) return res.status(404).json({ error: 'not_found' });
    const b = req.body ?? {};
    // Снимок прежней версии промпта/знаний — для отката
    await store.addAgentVersion(existing.id, existing.systemPrompt, existing.knowledge);
    const updated: AgentConfig = {
      ...existing,
      title: b.title !== undefined ? String(b.title) : existing.title,
      buttonLabel: b.buttonLabel !== undefined ? String(b.buttonLabel) : existing.buttonLabel,
      tariff: b.tariff !== undefined ? asTariff(b.tariff) : existing.tariff,
      systemPrompt: b.systemPrompt !== undefined ? String(b.systemPrompt) : existing.systemPrompt,
      knowledge: b.knowledge !== undefined ? String(b.knowledge) : existing.knowledge,
      model: b.model !== undefined ? (b.model ? String(b.model) : undefined) : existing.model,
      folders: b.folders !== undefined ? asFolders(b.folders) : existing.folders,
      comment: b.comment !== undefined ? String(b.comment) : existing.comment,
      enabled: b.enabled !== undefined ? b.enabled !== false : existing.enabled,
      updatedAt: new Date().toISOString(),
    };
    res.json(await store.updateAgent(updated));
  }),
);

adminRouter.delete(
  '/agents/:id',
  requireRole('admin'),
  h(async (req, res) => {
    await store.deleteAgent(req.params.id);
    res.json({ ok: true });
  }),
);

adminRouter.get(
  '/agents/:id/versions',
  h(async (req, res) => {
    res.json(await store.listAgentVersions(req.params.id));
  }),
);

adminRouter.post(
  '/agents/:id/rollback/:versionId',
  requireRole('admin'),
  h(async (req, res) => {
    const existing = await store.getAgentConfig(req.params.id);
    if (!existing) return res.status(404).json({ error: 'not_found' });
    const versions = await store.listAgentVersions(req.params.id);
    const v = versions.find((x) => x.id === Number(req.params.versionId));
    if (!v) return res.status(404).json({ error: 'version_not_found' });
    // Текущее состояние тоже сохраняем как версию, потом откатываемся
    await store.addAgentVersion(existing.id, existing.systemPrompt, existing.knowledge);
    res.json(
      await store.updateAgent({
        ...existing,
        systemPrompt: v.systemPrompt,
        knowledge: v.knowledge,
        updatedAt: new Date().toISOString(),
      }),
    );
  }),
);

// --- Общая база знаний ---
adminRouter.get(
  '/knowledge',
  h(async (_req, res) => {
    res.json({ global: (await store.getSetting('knowledge_global')) ?? '' });
  }),
);
adminRouter.put(
  '/knowledge',
  requireRole('admin'),
  h(async (req, res) => {
    await store.setSetting('knowledge_global', String(req.body?.global ?? ''));
    res.json({ ok: true });
  }),
);

// --- Извлечение текста из файла для базы знаний (PDF/текстовые форматы) ---
// Принимает { name, type, dataBase64 }, возвращает { text } для вставки в знания.
adminRouter.post(
  '/extract',
  requireRole('admin'),
  h(async (req, res) => {
    const b = req.body ?? {};
    const name = String(b.name ?? 'файл');
    const type = String(b.type ?? '');
    const b64 = String(b.dataBase64 ?? '').replace(/^data:[^;]+;base64,/, '');
    if (!b64) return res.status(400).json({ error: 'no_file' });
    const buf = Buffer.from(b64, 'base64');
    const ex = await extractFile(buf, type, name);
    if (ex.kind === 'text' && ex.text) return res.json({ text: ex.text, name });
    if (ex.kind === 'image') {
      return res.status(415).json({ error: 'image_unsupported' });
    }
    return res.status(415).json({ error: 'extract_failed', detail: ex.error ?? '' });
  }),
);

// --- Папки агентов (для подсказок/выбора в редакторе) ---
adminRouter.get(
  '/folders',
  h(async (_req, res) => {
    const fromList = await getFoldersList();
    const agents = await store.listAgents(true);
    const fromAgents = agents.flatMap((a) => a.folders ?? []);
    res.json([...new Set([...fromList, ...fromAgents])].sort((a, b) => a.localeCompare(b, 'ru')));
  }),
);
adminRouter.post(
  '/folders',
  requireRole('admin'),
  h(async (req, res) => {
    const name = String(req.body?.name ?? '').trim();
    if (!name) return res.status(400).json({ error: 'no_name' });
    const list = await getFoldersList();
    if (!list.includes(name)) {
      list.push(name);
      await setFoldersList(list);
    }
    res.json({ ok: true, name });
  }),
);
adminRouter.put(
  '/folders/:name',
  requireRole('admin'),
  h(async (req, res) => {
    const oldName = req.params.name;
    const newName = String(req.body?.name ?? '').trim();
    if (!newName) return res.status(400).json({ error: 'no_name' });
    if (newName === oldName) return res.json({ ok: true, name: newName });

    const list = await getFoldersList();
    const nextList = list.filter((f) => f !== oldName);
    nextList.push(newName);
    await setFoldersList(nextList);

    const agents = await store.listAgents(true);
    for (const a of agents) {
      if (!(a.folders ?? []).includes(oldName)) continue;
      const folders = [...new Set((a.folders ?? []).map((f) => (f === oldName ? newName : f)))];
      await store.updateAgent({ ...a, folders, updatedAt: new Date().toISOString() });
    }
    res.json({ ok: true, name: newName });
  }),
);

// --- Модель по умолчанию для всех агентов (если у агента модель не задана) ---
adminRouter.get(
  '/model-default',
  h(async (_req, res) => {
    res.json({
      model: (await store.getSetting('model_default')) ?? '',
      envDefault: config.llm.model,
    });
  }),
);
adminRouter.put(
  '/model-default',
  requireRole('admin'),
  h(async (req, res) => {
    await store.setSetting('model_default', String(req.body?.model ?? ''));
    res.json({ ok: true });
  }),
);

// --- Цены (рублей за 1000 токенов) ---
adminRouter.get(
  '/pricing',
  h(async (_req, res) => {
    res.json({
      inputPer1k: Number((await store.getSetting('price_input_per_1k')) ?? 0),
      outputPer1k: Number((await store.getSetting('price_output_per_1k')) ?? 0),
    });
  }),
);
adminRouter.put(
  '/pricing',
  requireRole('admin'),
  h(async (req, res) => {
    await store.setSetting('price_input_per_1k', String(Number(req.body?.inputPer1k ?? 0)));
    await store.setSetting('price_output_per_1k', String(Number(req.body?.outputPer1k ?? 0)));
    res.json({ ok: true });
  }),
);

// --- Расход токенов (по агентам + итог + рубли) ---
adminRouter.get(
  '/usage',
  h(async (_req, res) => {
    const usage = await store.getAgentUsage();
    const agents = await store.listAgents(true);
    const titleById = new Map(agents.map((a) => [a.id, a.title]));
    const inPrice = Number((await store.getSetting('price_input_per_1k')) ?? 0);
    const outPrice = Number((await store.getSetting('price_output_per_1k')) ?? 0);
    const rub = (inTok: number, outTok: number) => (inTok / 1000) * inPrice + (outTok / 1000) * outPrice;
    const rows = usage.map((u) => ({
      agentId: u.agentId,
      title: titleById.get(u.agentId) ?? u.agentId,
      requests: u.requests,
      inputTokens: u.inputTokens,
      outputTokens: u.outputTokens,
      rubles: Math.round(rub(u.inputTokens, u.outputTokens) * 100) / 100,
    }));
    const total = rows.reduce(
      (acc, r) => ({
        requests: acc.requests + r.requests,
        inputTokens: acc.inputTokens + r.inputTokens,
        outputTokens: acc.outputTokens + r.outputTokens,
        rubles: Math.round((acc.rubles + r.rubles) * 100) / 100,
      }),
      { requests: 0, inputTokens: 0, outputTokens: 0, rubles: 0 },
    );
    res.json({ rows, total });
  }),
);

// --- Просмотр диалогов ---
adminRouter.get(
  '/users',
  h(async (_req, res) => {
    const users = await store.listUsers();
    res.json(users.map((u) => ({ telegramId: u.telegramId, name: u.name, email: u.gcEmail })));
  }),
);
adminRouter.get(
  '/users/:id/history',
  h(async (req, res) => {
    res.json(await store.getSharedHistory(Number(req.params.id)));
  }),
);

// Сводка по пользователю: токены (вход/выход) + число сообщений от каждой стороны.
const KICKOFF = 'Здравствуйте! Я готов начать — подскажите, с чего начать.';
adminRouter.get(
  '/users/:id/stats',
  h(async (req, res) => {
    const id = Number(req.params.id);
    const usage = await store.getUserUsageTotal(id);
    const history = await store.getSharedHistory(id);
    // Скрытое стартовое сообщение не считаем за реплику пользователя.
    const userMessages = history.filter((m) => m.role === 'user' && m.content !== KICKOFF).length;
    const agentMessages = history.filter((m) => m.role === 'assistant').length;

    // Разбивка по агентам: из диалогов пользователя (в каждом сообщении есть токены).
    const dialogs = await store.getUserDialogs(id);
    const agents = await store.listAgents(true);
    const titleById = new Map(agents.map((a) => [a.id, a.title]));
    const rub = await rubCalc();
    const byAgent = dialogs
      .map((d) => {
        let inTok = 0;
        let outTok = 0;
        let uMsg = 0;
        let aMsg = 0;
        for (const m of d.messages) {
          if (m.role === 'user') {
            if (m.content !== KICKOFF) uMsg += 1;
            inTok += m.tokens ?? 0;
          } else if (m.role === 'assistant') {
            aMsg += 1;
            outTok += m.tokens ?? 0;
          }
        }
        return {
          agentId: d.agentId,
          title: titleById.get(d.agentId) ?? d.agentId,
          inputTokens: inTok,
          outputTokens: outTok,
          userMessages: uMsg,
          agentMessages: aMsg,
          rubles: rub(inTok, outTok),
        };
      })
      .sort((a, b) => b.rubles - a.rubles);

    res.json({
      requests: usage.requests,
      inputTokens: usage.inputTokens,
      outputTokens: usage.outputTokens,
      userMessages,
      agentMessages,
      rubles: rub(usage.inputTokens, usage.outputTokens),
      byAgent,
    });
  }),
);

// --- Сравнение моделей: один и тот же вопрос разным моделям, рядом ---
// Прогоняет вопрос (опц. в контексте промпта агента) через список моделей
// параллельно и возвращает ответ + токены + стоимость + время по каждой.
adminRouter.post(
  '/compare',
  requireRole('admin'),
  h(async (req, res) => {
    const b = req.body ?? {};
    const question = String(b.question ?? '').trim();
    if (!question) return res.status(400).json({ error: 'no_question' });
    const models: string[] = Array.isArray(b.models)
      ? [...new Set((b.models as unknown[]).map((m) => String(m).trim()).filter((m) => m.length > 0))]
      : [];
    if (!models.length) return res.status(400).json({ error: 'no_models' });
    if (models.length > 6) return res.status(400).json({ error: 'too_many_models' });

    // Опциональный контекст агента: его системный промпт + база знаний.
    let system = '';
    if (b.agentId) {
      const agent = await store.getAgentConfig(String(b.agentId));
      if (agent) {
        const parts = [agent.systemPrompt];
        const globalKnowledge = (await store.getSetting('knowledge_global')) ?? '';
        if (globalKnowledge.trim()) parts.push(`База знаний (общая):\n${globalKnowledge}`);
        if (agent.knowledge.trim()) parts.push(`База знаний (по теме):\n${agent.knowledge}`);
        system = parts.join('\n\n');
      }
    }
    const base: ChatMessage[] = system ? [{ role: 'system', content: system }] : [];
    const messages: ChatMessage[] = [...base, { role: 'user', content: question }];
    const rub = await rubCalc();

    const results = await Promise.all(
      models.map(async (model) => {
        const started = Date.now();
        try {
          const r = await chatComplete(messages, model);
          return {
            model,
            content: r.content,
            inputTokens: r.inputTokens,
            outputTokens: r.outputTokens,
            rubles: rub(r.inputTokens, r.outputTokens),
            ms: Date.now() - started,
          };
        } catch (e) {
          return { model, error: (e as Error).message, ms: Date.now() - started };
        }
      }),
    );
    res.json({ results });
  }),
);

// --- Доступы: учётные записи админов и их роли (только супер-админ) ---
const ROLE_VALUES: AdminRole[] = ['viewer', 'admin', 'super_admin'];
const asRole = (v: unknown): AdminRole | null => (ROLE_VALUES.includes(v as AdminRole) ? (v as AdminRole) : null);

adminRouter.get(
  '/admins',
  requireRole('super_admin'),
  h(async (_req, res) => {
    const list = await store.listAdminUsers();
    res.json(list.map((a) => ({ id: a.id, username: a.username, role: a.role, createdAt: a.createdAt })));
  }),
);

adminRouter.post(
  '/admins',
  requireRole('super_admin'),
  h(async (req, res) => {
    const username = String(req.body?.username ?? '').trim();
    const password = String(req.body?.password ?? '');
    const role = asRole(req.body?.role);
    if (!username || password.length < 8 || !role) return res.status(400).json({ error: 'invalid_input' });
    if (await store.getAdminUserByUsername(username)) return res.status(409).json({ error: 'username_taken' });
    const created = await store.createAdminUser(username, hashPassword(password), role);
    res.json({ id: created.id, username: created.username, role: created.role, createdAt: created.createdAt });
  }),
);

adminRouter.put(
  '/admins/:id',
  requireRole('super_admin'),
  h(async (req, res) => {
    const id = Number(req.params.id);
    const patch: { role?: AdminRole; passwordHash?: string } = {};
    if (req.body?.role !== undefined) {
      const role = asRole(req.body.role);
      if (!role) return res.status(400).json({ error: 'invalid_role' });
      // Не даём супер-админу разжаловать себя — иначе можно случайно остаться без доступа к управлению доступами.
      if (id === req.adminUser?.id && role !== 'super_admin') {
        return res.status(400).json({ error: 'cannot_demote_self' });
      }
      patch.role = role;
    }
    if (req.body?.password !== undefined) {
      const password = String(req.body.password);
      if (password.length < 8) return res.status(400).json({ error: 'weak_password' });
      patch.passwordHash = hashPassword(password);
    }
    const updated = await store.updateAdminUser(id, patch);
    if (!updated) return res.status(404).json({ error: 'not_found' });
    res.json({ id: updated.id, username: updated.username, role: updated.role, createdAt: updated.createdAt });
  }),
);

adminRouter.delete(
  '/admins/:id',
  requireRole('super_admin'),
  h(async (req, res) => {
    const id = Number(req.params.id);
    if (id === req.adminUser?.id) return res.status(400).json({ error: 'cannot_delete_self' });
    await store.deleteAdminUser(id);
    res.json({ ok: true });
  }),
);

// Информация о текущем вошедшем админе (для UI — какие разделы показывать).
adminRouter.get(
  '/me',
  h(async (req, res) => {
    res.json({ username: req.adminUser?.username, role: req.adminUser?.role });
  }),
);
