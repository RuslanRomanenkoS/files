// Стабильный числовой id из email — общий для всех реализаций хранилища.
// Пользователи из Геткурса не имеют telegramId, поэтому id выводим из email:
// один и тот же email всегда даёт один и тот же id (12 hex = 48 бит, в пределах
// безопасного целого JS и BIGINT Postgres).
import crypto from 'node:crypto';

export function emailToId(email: string): number {
  const h = crypto.createHash('sha256').update(email.toLowerCase().trim()).digest('hex').slice(0, 12);
  return parseInt(h, 16);
}
