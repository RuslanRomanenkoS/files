// Конфигурация из переменных окружения с безопасными значениями по умолчанию.
import process from 'node:process';

// Подгружаем .env (Node 20.12+/26). Если файла нет — тихо игнорируем.
try {
  process.loadEnvFile();
} catch {
  /* .env не обязателен (например, в проде переменные задаются окружением) */
}

export const config = {
  port: Number(process.env.PORT ?? 3000),

  // Постоянное хранилище. Если DATABASE_URL не задан — работаем в памяти (dev).
  database: {
    url: process.env.DATABASE_URL ?? '',
  },

  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN ?? '',
    // dev — пропускаем без подписи (локально); strict — требуем валидный initData
    authMode: (process.env.AUTH_MODE ?? 'dev') as 'dev' | 'strict',
    // Публичный HTTPS-адрес Mini App (для кнопки запуска в боте)
    webappUrl: process.env.WEBAPP_URL ?? '',
  },

  llm: {
    apiKey: process.env.PROXYAPI_KEY ?? '',
    baseUrl: process.env.PROXYAPI_BASE_URL ?? 'https://api.proxyapi.ru/openai/v1',
    model: process.env.LLM_MODEL ?? 'gpt-4o',
    // Модель распознавания речи (голосовой ввод). ProxyAPI = OpenAI-совместимый.
    sttModel: process.env.STT_MODEL ?? 'whisper-1',
    // Если ключа нет — работаем на мок-ответах (для разработки без расходов)
    get enabled() {
      return this.apiKey.length > 0;
    },
  },

  getcourse: {
    apiKey: process.env.GETCOURSE_API_KEY ?? '',
    account: process.env.GETCOURSE_ACCOUNT ?? '',
    webhookSecret: process.env.GETCOURSE_WEBHOOK_SECRET ?? '',
    get enabled() {
      return this.apiKey.length > 0 && this.account.length > 0;
    },
  },

  // Админ-панель: один общий вход. Без ADMIN_PASSWORD панель отключена.
  admin: {
    password: process.env.ADMIN_PASSWORD ?? '',
    // Секрет подписи сессионного токена. Если не задан — выводится из пароля.
    tokenSecret: process.env.ADMIN_TOKEN_SECRET ?? '',
    get enabled() {
      return this.password.length > 0;
    },
  },

  // Подписанный токен виджета: защита от вызова в обход Геткурса. Пусто — выключено.
  widget: {
    tokenSecret: process.env.WIDGET_TOKEN_SECRET ?? '',
  },
};
