// Слой памяти: формирует контекст для агента из профиля пользователя
// и (сжатой) истории диалога, чтобы человек не представлялся заново.
import { store } from '../store.js';
import { chatComplete } from './llm.js';
import type { ChatMessage, Profile } from '../types.js';

// Профиль -> текстовый блок для системного промпта (общий для всех агентов).
export function profileContext(profile: Profile | undefined): string {
  if (!profile) return '';
  const lines: string[] = [];
  if (profile.niche) lines.push(`Ниша: ${profile.niche}`);
  if (profile.product) lines.push(`Продукт: ${profile.product}`);
  if (profile.audience) lines.push(`Целевая аудитория: ${profile.audience}`);
  if (profile.avgCheck) lines.push(`Средний чек: ${profile.avgCheck}`);
  if (profile.notes) lines.push(`Заметки: ${profile.notes}`);
  if (!lines.length) return '';
  return `Контекст о пользователе (используй, не переспрашивая):\n${lines.join('\n')}`;
}

// История ОДНОГО агента (для отображения треда в интерфейсе).
const HISTORY_TAIL = 12;

export async function loadHistory(telegramId: number, agentId: string): Promise<ChatMessage[]> {
  const dialog = await store.getDialog(telegramId, agentId);
  if (!dialog) return [];
  return dialog.messages.slice(-HISTORY_TAIL);
}

export async function appendHistory(
  telegramId: number,
  agentId: string,
  userMsg: ChatMessage,
  assistantMsg: ChatMessage,
) {
  const existing = await store.getDialog(telegramId, agentId);
  const messages = [...(existing?.messages ?? []), userMsg, assistantMsg];
  await store.saveDialog({ telegramId, agentId, messages, updatedAt: new Date().toISOString() });
}

// СКВОЗНАЯ память: контекст из всех диалогов пользователя со всеми агентами.
// Подаётся в модель, чтобы агент помнил, что обсуждалось с другими агентами.
//
// Смысловое сжатие: пока история короткая — отдаём её хвост целиком. Когда она
// разрастается, старая часть сворачивается в краткую «сводку» (LLM), а в модель
// идёт [сводка + последние RECENT_TAIL сообщений дословно]. Так агент помнит суть
// давнего общения, не раздувая контекст.
const SHARED_TAIL = 16; // хвост, пока сжатие не включилось
const RECENT_TAIL = 12; // сколько последних сообщений всегда идёт дословно
const SUMMARY_THRESHOLD = 20; // включаем сжатие, когда история длиннее этого
const REFRESH_BATCH = 8; // пересобираем сводку, накопив столько новых сообщений

// Контекст сквозной памяти для модели: либо хвост (коротко), либо сводка + хвост.
export async function loadMemoryContext(telegramId: number): Promise<ChatMessage[]> {
  const full = await store.getSharedHistory(telegramId);
  const summary = await store.getSummary(telegramId);
  if (summary && summary.summary) {
    const recent = full.slice(summary.coveredCount);
    const note: ChatMessage = {
      role: 'system',
      content: `Сводка предыдущего общения с пользователем (помни эти факты):\n${summary.summary}`,
    };
    return [note, ...recent];
  }
  return full.slice(-SHARED_TAIL);
}

export async function appendSharedHistory(
  telegramId: number,
  userMsg: ChatMessage,
  assistantMsg: ChatMessage,
) {
  await store.appendShared(telegramId, userMsg, assistantMsg);
}

// Best-effort обновление сводки после нового сообщения. Ошибки не пробрасываем —
// сжатие памяти не должно ломать основной ответ агента.
export async function maybeSummarize(telegramId: number): Promise<void> {
  try {
    const full = await store.getSharedHistory(telegramId);
    const total = full.length;
    if (total <= SUMMARY_THRESHOLD) return;

    const existing = await store.getSummary(telegramId);
    const covered = existing?.coveredCount ?? 0;
    const targetCovered = total - RECENT_TAIL;
    if (targetCovered - covered < REFRESH_BATCH) return;

    const toFold = full.slice(covered, targetCovered);
    const transcript = toFold
      .map((m) => `${m.role === 'user' ? 'Пользователь' : 'Ассистент'}: ${m.content}`)
      .join('\n');

    const result = await chatComplete([
      {
        role: 'system',
        content:
          'Ты ведёшь краткую сводку фактов о пользователе и ходе диалога для ИИ-ассистента по продажам. ' +
          'Сохраняй: нишу/бизнес, продукт, целевую аудиторию, цели, договорённости, важные детали и решения. ' +
          'Пиши кратко и тезисно, по-русски. Обновляй сводку новыми фактами, не теряя прежние.',
      },
      {
        role: 'user',
        content:
          `Текущая сводка:\n${existing?.summary || '(пусто)'}\n\n` +
          `Новые сообщения диалога:\n${transcript}\n\n` +
          'Выдай обновлённую сводку.',
      },
    ]);

    await store.saveSummary(telegramId, result.content.trim(), targetCovered);
    await store.addUsage(telegramId, result.inputTokens, result.outputTokens);
  } catch (e) {
    console.error('Сжатие памяти не удалось (не критично):', e);
  }
}

export async function fullSharedHistory(telegramId: number): Promise<ChatMessage[]> {
  return store.getSharedHistory(telegramId);
}
