// Слой памяти: формирует контекст для агента из профиля пользователя
// и (сжатой) истории диалога, чтобы человек не представлялся заново.
import { store } from '../store.js';
import type { ChatMessage, Profile } from '../types.js';

// Профиль -> текстовый блок для системного промпта (общий для всех агентов).
export function profileContext(profile: Profile | undefined): string {
  if (!profile) return '';
  const lines: string[] = [];
  if (profile.niche) lines.push(`Ниша: ${profile.niche}`);
  if (profile.product) lines.push(`Продукт: ${profile.product}`);
  if (profile.audience) lines.push(`Целевая аудитория: ${profile.audience}`);
  if (profile.avgCheck) lines.push(`Средний чек: ${profile.avgCheck}`);
  if (profile.notes) lines.push(`Заметки: ${profile.notes}`);
  if (!lines.length) return '';
  return `Контекст о пользователе (используй, не переспрашивая):\n${lines.join('\n')}`;
}

// История ОДНОГО агента (для отображения треда в интерфейсе).
const HISTORY_TAIL = 12;

export async function loadHistory(telegramId: number, agentId: string): Promise<ChatMessage[]> {
  const dialog = await store.getDialog(telegramId, agentId);
  if (!dialog) return [];
  return dialog.messages.slice(-HISTORY_TAIL);
}

export async function appendHistory(
  telegramId: number,
  agentId: string,
  userMsg: ChatMessage,
  assistantMsg: ChatMessage,
) {
  const existing = await store.getDialog(telegramId, agentId);
  const messages = [...(existing?.messages ?? []), userMsg, assistantMsg];
  await store.saveDialog({ telegramId, agentId, messages, updatedAt: new Date().toISOString() });
}

// СКВОЗНАЯ память: контекст из всех диалогов пользователя со всеми агентами.
// Подаётся в модель, чтобы агент помнил, что обсуждалось с другими агентами.
// Хвост ограничен для контроля токенов (позже заменим на смысловое сжатие).
const SHARED_TAIL = 16;

export async function loadSharedHistory(telegramId: number): Promise<ChatMessage[]> {
  return (await store.getSharedHistory(telegramId)).slice(-SHARED_TAIL);
}

export async function appendSharedHistory(
  telegramId: number,
  userMsg: ChatMessage,
  assistantMsg: ChatMessage,
) {
  await store.appendShared(telegramId, userMsg, assistantMsg);
}

export async function fullSharedHistory(telegramId: number): Promise<ChatMessage[]> {
  return store.getSharedHistory(telegramId);
}
