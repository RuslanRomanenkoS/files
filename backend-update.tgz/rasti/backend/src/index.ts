import express from 'express';
import cors from 'cors';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync } from 'node:fs';
import { config } from './config.js';
import { authMiddleware, type AuthedRequest } from './auth.js';
import { store, initStore } from './store.js';
import { listAgents, getAgent, publicAgent } from './services/agents.js';
import { checkAgentAccess } from './services/access.js';
import { checkDailyLimit } from './services/limits.js';
import {
  profileContext,
  loadHistory,
  appendHistory,
  loadSharedHistory,
  appendSharedHistory,
  fullSharedHistory,
} from './services/memory.js';
import { chatComplete } from './services/llm.js';
import type { ChatMessage, Profile } from './types.js';

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Обёртка для async-обработчиков: Express 4 сам не ловит reject промиса,
// поэтому пробрасываем ошибку в глобальный обработчик (иначе запрос зависнет).
type Handler = (req: AuthedRequest, res: express.Response) => unknown | Promise<unknown>;
const ah =
  (fn: Handler) =>
  (req: express.Request, res: express.Response, next: express.NextFunction) =>
    Promise.resolve(fn(req as AuthedRequest, res)).catch(next);

// --- Здоровье ---
app.get('/health', (_req, res) => {
  res.json({ ok: true, llm: config.llm.enabled ? 'live' : 'mock', auth: config.telegram.authMode });
});

// --- Кто я + мой доступ (для личного кабинета и шапки) ---
app.get('/api/me', authMiddleware, ah(async (req, res) => {
  const u = req.user!;
  res.json({
    name: u.name,
    tariff: u.tariff,
    accessActive: u.accessActive,
    accessUntil: u.accessUntil,
    hasProfile: Boolean(await store.getProfile(u.telegramId)),
  });
}));

// --- Список агентов, доступных пользователю по тарифу ---
app.get('/api/agents', authMiddleware, (req: AuthedRequest, res) => {
  const u = req.user!;
  const all = listAgents().map(publicAgent);
  res.json(all.map((a) => ({ ...a, unlocked: u.tariff === 'team' || a.tariff === 'personal' })));
});

// --- Профиль/анкета (память) ---
app.get('/api/profile', authMiddleware, ah(async (req, res) => {
  res.json((await store.getProfile(req.user!.telegramId)) ?? null);
}));

app.put('/api/profile', authMiddleware, ah(async (req, res) => {
  const u = req.user!;
  const body = req.body ?? {};
  const profile: Profile = {
    telegramId: u.telegramId,
    niche: String(body.niche ?? ''),
    product: String(body.product ?? ''),
    audience: String(body.audience ?? ''),
    avgCheck: String(body.avgCheck ?? ''),
    notes: String(body.notes ?? ''),
    updatedAt: new Date().toISOString(),
  };
  res.json(await store.saveProfile(profile));
}));

// --- История диалога с конкретным агентом (для треда в интерфейсе) ---
app.get('/api/chat/:agentId/history', authMiddleware, ah(async (req, res) => {
  const history = await loadHistory(req.user!.telegramId, req.params.agentId);
  res.json(history);
}));

// --- Сквозная память: вся история пользователя со всеми агентами ---
app.get('/api/memory', authMiddleware, ah(async (req, res) => {
  res.json(await fullSharedHistory(req.user!.telegramId));
}));

// --- Отправка сообщения агенту (ядро) ---
app.post('/api/chat/:agentId', authMiddleware, ah(async (req, res) => {
  const u = req.user!;
  const agent = getAgent(req.params.agentId);
  if (!agent) return res.status(404).json({ error: 'agent_not_found' });

  // 1) Контроль доступа (доступ к курсу + тариф)
  const access = checkAgentAccess(u, agent.tariff);
  if (!access.allowed) return res.status(403).json({ error: access.reason });

  // 2) Контроль расходов (дневной лимит по тарифу)
  const limit = await checkDailyLimit(u.telegramId, u.tariff);
  if (!limit.allowed) {
    return res.status(429).json({ error: 'daily_limit', used: limit.used, limit: limit.limit });
  }

  const text = String(req.body?.message ?? '').trim();
  if (!text) return res.status(400).json({ error: 'empty_message' });

  // 3) Сборка контекста: промпт агента + профиль + СКВОЗНАЯ память (все агенты)
  const ctx = profileContext(await store.getProfile(u.telegramId));
  const system: ChatMessage = {
    role: 'system',
    content: ctx ? `${agent.systemPrompt}\n\n${ctx}` : agent.systemPrompt,
  };
  // Сквозная память: агент видит контекст из всех прежних диалогов пользователя
  const history = await loadSharedHistory(u.telegramId);
  const userMsg: ChatMessage = { role: 'user', content: text };
  const messages: ChatMessage[] = [system, ...history, userMsg];

  // 4) Вызов LLM (ProxyAPI или мок)
  try {
    const result = await chatComplete(messages, agent.model);
    const assistantMsg: ChatMessage = { role: 'assistant', content: result.content };

    // 5) Сохранение истории (по агенту + сквозная) и учёт расходов
    await appendHistory(u.telegramId, agent.id, userMsg, assistantMsg);
    await appendSharedHistory(u.telegramId, userMsg, assistantMsg);
    await store.addUsage(u.telegramId, result.inputTokens, result.outputTokens);

    res.json({ reply: result.content });
  } catch (e) {
    console.error('LLM error:', e);
    res.status(502).json({ error: 'llm_failed' });
  }
}));

// --- Вебхук Геткурса: обновление доступа (оплата/выдача/отзыв) ---
// Поддерживает и GET, и POST; данные принимаются из URL (query) ИЛИ из тела.
// Это позволяет использовать операцию ГК «Вызвать url» (данные в адресе).
// Если пользователя ещё нет в нашей базе — создаём его по email (доступ
// применится, когда он откроет виджет).
async function getcourseWebhook(req: express.Request, res: express.Response) {
  const data: Record<string, unknown> = { ...(req.query ?? {}), ...(req.body ?? {}) };

  const secret = data.secret;
  if (config.getcourse.webhookSecret && secret !== config.getcourse.webhookSecret) {
    return res.status(401).json({ error: 'bad_secret' });
  }

  const email = data.email ? String(data.email).trim() : '';
  if (!email) return res.status(400).json({ error: 'no_email' });

  // accessActive может прийти булевым или строкой "true"/"false"/"1"/"0"
  let accessActive: boolean | undefined;
  if (typeof data.accessActive === 'boolean') accessActive = data.accessActive;
  else if (typeof data.accessActive === 'string') {
    accessActive = ['true', '1', 'yes'].includes(data.accessActive.toLowerCase());
  }

  const tariff = data.tariff === 'team' ? 'team' : data.tariff === 'personal' ? 'personal' : undefined;
  const accessUntil = data.accessUntil ? String(data.accessUntil) : undefined;

  // Находим пользователя по email или создаём (чтобы доступ сохранился заранее)
  const user = (await store.getUserByEmail(email)) ?? (await store.upsertGkUser(email));
  if (tariff) user.tariff = tariff;
  if (accessActive !== undefined) user.accessActive = accessActive;
  if (accessUntil) user.accessUntil = accessUntil;
  await store.upsertUser(user);

  res.json({ ok: true, email, tariff: user.tariff, accessActive: user.accessActive });
}
app.get('/webhooks/getcourse', ah(getcourseWebhook));
app.post('/webhooks/getcourse', ah(getcourseWebhook));

// Утилита: генерация секрета вебхука (для удобства настройки)
app.get('/util/gen-secret', (_req, res) => res.json({ secret: crypto.randomBytes(16).toString('hex') }));

// --- Отдача собранного Mini App (mini-app/dist), если он есть ---
// Позволяет открывать весь продукт с одного HTTPS-адреса (туннель/VPS).
const here = path.dirname(fileURLToPath(import.meta.url));
const webDist = path.resolve(here, '../../mini-app/dist');
if (existsSync(webDist)) {
  app.use(express.static(webDist));
  // SPA-fallback: любые не-API маршруты отдают index.html
  app.get(/^\/(?!api|webhooks|health|util).*/, (_req, res) => {
    res.sendFile(path.join(webDist, 'index.html'));
  });
  console.log(`  Mini App: отдаётся из ${webDist}`);
}

// Глобальный обработчик ошибок (ловит reject из async-обработчиков через ah()).
app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('Ошибка запроса:', err);
  if (!res.headersSent) res.status(500).json({ error: 'server_error' });
});

// Инициализируем хранилище (Postgres или память) ДО приёма запросов.
initStore()
  .then(() => {
    app.listen(config.port, () => {
      console.log(`Backend на http://localhost:${config.port}`);
      console.log(`  LLM: ${config.llm.enabled ? 'ProxyAPI (live)' : 'МОК (без ключа)'}`);
      console.log(`  Auth: ${config.telegram.authMode}`);
      console.log(`  Хранилище: ${config.database.url ? 'PostgreSQL' : 'память (dev)'}`);
    });
  })
  .catch((e) => {
    console.error('Не удалось инициализировать хранилище:', e);
    process.exit(1);
  });
