// Проверка Telegram initData (HMAC-SHA256 по схеме Telegram WebApp).
// Достоверно подтверждает, какой пользователь открыл Mini App, — основа контроля доступа.
import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { config } from './config.js';
import { store } from './store.js';
import type { User } from './types.js';

export interface AuthedRequest extends Request {
  user?: User;
}

interface TgUser {
  id: number;
  first_name?: string;
}

// Возвращает данные пользователя, если подпись валидна; иначе null.
export function verifyInitData(initData: string, botToken: string): TgUser | null {
  if (!initData || !botToken) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash) return null;
  params.delete('hash');

  // data_check_string — пары key=value, отсортированные по ключу, через \n
  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const computed = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
  if (computed !== hash) return null;

  try {
    const userRaw = params.get('user');
    return userRaw ? (JSON.parse(userRaw) as TgUser) : null;
  } catch {
    return null;
  }
}

// Middleware: определяет пользователя из одного из источников:
//   1) Telegram Mini App — заголовок Authorization: tma <initData> (подпись)
//   2) Геткурс-виджет    — заголовок X-GK-User: <email>|<имя>
//   3) dev-режим         — демо-пользователь
//
// TODO (безопасность ГК): сейчас доверяем email из заголовка. На проде —
// подписанный токен от ГК ИЛИ перепроверка доступа через API Геткурса.
export async function authMiddleware(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    await resolveUser(req, res, next);
  } catch (e) {
    next(e);
  }
}

async function resolveUser(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.header('authorization') ?? '';
  const initData = header.startsWith('tma ') ? header.slice(4) : '';
  // Значение приходит URL-кодированным (в заголовках нельзя не-latin)
  let gkHeader = req.header('x-gk-user') ?? '';
  try {
    gkHeader = decodeURIComponent(gkHeader);
  } catch {
    /* оставляем как есть, если декодирование не удалось */
  }

  // 1) Telegram
  const tgUser = verifyInitData(initData, config.telegram.botToken);
  if (tgUser) {
    let user = await store.getUser(tgUser.id);
    if (!user) {
      user = await store.upsertUser({
        telegramId: tgUser.id,
        name: tgUser.first_name ?? 'Пользователь',
        gcEmail: null,
        gcUserId: null,
        tariff: 'personal',
        accessActive: false,
        accessUntil: null,
      });
    }
    req.user = user;
    return next();
  }

  // 2) Геткурс
  if (gkHeader) {
    const [email, name] = gkHeader.split('|');
    if (email) {
      req.user = await store.upsertGkUser(email.trim(), name?.trim());
      return next();
    }
  }

  // 3) dev-режим — демо-пользователь; в strict — отказ
  if (config.telegram.authMode === 'dev') {
    req.user = await store.upsertUser(
      (await store.getUser(123456789)) ?? {
        telegramId: 123456789,
        name: 'Руслан',
        gcEmail: 'demo@example.com',
        gcUserId: 'gc-1',
        tariff: 'team',
        accessActive: true,
        accessUntil: '2026-12-31',
      },
    );
    return next();
  }

  return res.status(401).json({ error: 'unauthorized' });
}
