// Движко-независимый слой LLM. Сейчас — адаптер ProxyAPI (OpenAI-совместимый).
// Без ключа возвращает МОК-ответ, чтобы разрабатывать без расходов.
// Чтобы переключиться на VseGPT/AITunnel/Claude — меняется baseUrl/model, не код.
import { spawn } from 'node:child_process';
import { config } from '../config.js';
import type { ChatMessage } from '../types.js';

export interface LlmResult {
  content: string;
  inputTokens: number;
  outputTokens: number;
}

export async function chatComplete(
  messages: ChatMessage[],
  model?: string,
): Promise<LlmResult> {
  // МОК-режим: ключа нет
  if (!config.llm.enabled) {
    const lastUser = [...messages].reverse().find((m) => m.role === 'user');
    return {
      content:
        '[МОК-ответ LLM] Реальный ответ появится после подключения ProxyAPI.\n' +
        `Получено: «${lastUser?.content ?? ''}».`,
      inputTokens: roughTokens(messages.map((m) => m.content).join(' ')),
      outputTokens: 30,
    };
  }

  // Реальный вызов ProxyAPI (OpenAI Chat Completions)
  const res = await fetch(`${config.llm.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${config.llm.apiKey}`,
    },
    body: JSON.stringify({
      model: model ?? config.llm.model,
      messages: messages.map((m) => ({ role: m.role, content: m.content })),
      temperature: 0.7,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`LLM error ${res.status}: ${text}`);
  }

  const data = (await res.json()) as {
    choices: { message: { content: string } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number };
  };

  return {
    content: data.choices[0]?.message?.content ?? '',
    inputTokens: data.usage?.prompt_tokens ?? 0,
    outputTokens: data.usage?.completion_tokens ?? 0,
  };
}

// Грубая оценка токенов для мок-режима (≈4 символа на токен).
function roughTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

// Браузерный MediaRecorder пишет webm/opus без надёжных метаданных длительности —
// Whisper-совместимый эндпоинт такие файлы иногда отвергает («Cannot extract audio
// duration»). Прогоняем через ffmpeg в wav — формат, который принимается стабильно.
function convertToWav(audio: Buffer): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', [
      '-i', 'pipe:0',
      '-f', 'wav',
      '-ar', '16000',
      '-ac', '1',
      'pipe:1',
    ]);
    const chunks: Buffer[] = [];
    let stderr = '';
    proc.stdout.on('data', (c) => chunks.push(c));
    proc.stderr.on('data', (c) => (stderr += c));
    proc.on('error', reject);
    proc.on('close', (code) => {
      if (code !== 0) return reject(new Error(`ffmpeg exited ${code}: ${stderr.slice(-500)}`));
      resolve(Buffer.concat(chunks));
    });
    proc.stdin.write(audio);
    proc.stdin.end();
  });
}

// Распознавание речи: аудио → текст (для голосового ввода в виджете).
// Использует OpenAI-совместимый эндпоинт /audio/transcriptions (ProxyAPI).
// Без ключа возвращает заглушку, чтобы разрабатывать без расходов.
export async function transcribeAudio(audio: Buffer): Promise<string> {
  if (!config.llm.enabled) {
    return '[Голосовой ввод в мок-режиме] Подключите ключ — и здесь появится расшифровка.';
  }
  const wav = await convertToWav(audio);

  const form = new FormData();
  form.append('file', new Blob([new Uint8Array(wav)], { type: 'audio/wav' }), 'voice.wav');
  form.append('model', config.llm.sttModel);

  const res = await fetch(`${config.llm.baseUrl}/audio/transcriptions`, {
    method: 'POST',
    headers: { authorization: `Bearer ${config.llm.apiKey}` },
    body: form,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`STT error ${res.status}: ${text}`);
  }
  const data = (await res.json()) as { text?: string };
  return (data.text ?? '').trim();
}
