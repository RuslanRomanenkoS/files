// Постоянное хранилище на PostgreSQL. Подключается, когда задан DATABASE_URL.
// Схема создаётся автоматически при старте (init). Реализует тот же интерфейс
// Storage, что и MemoryStore, поэтому бизнес-логика не меняется.
import pg from 'pg';
import type { Storage } from './store.js';
import { newGkUser } from './store.js';
import type { ChatMessage, DialogTurn, Profile, UsageRecord, User } from './types.js';

const { Pool } = pg;

// Минимальный контракт клиента БД: и pg.Pool, и совместимые движки (для тестов)
// предоставляют query(text, params) -> { rows }.
export interface Queryable {
  query<R extends Record<string, unknown> = Record<string, unknown>>(
    text: string,
    params?: unknown[],
  ): Promise<{ rows: R[] }>;
}

const today = () => new Date().toISOString().slice(0, 10);

// pg отдаёт BIGINT строкой — приводим к number (id умещается в безопасное целое).
type UserRow = {
  telegram_id: string;
  name: string;
  gc_email: string | null;
  gc_user_id: string | null;
  tariff: string;
  access_active: boolean;
  access_until: string | null;
};

function rowToUser(r: UserRow): User {
  return {
    telegramId: Number(r.telegram_id),
    name: r.name,
    gcEmail: r.gc_email,
    gcUserId: r.gc_user_id,
    tariff: r.tariff === 'team' ? 'team' : 'personal',
    accessActive: r.access_active,
    accessUntil: r.access_until,
  };
}

export class PostgresStore implements Storage {
  private pool: Queryable;

  // url — строка подключения (прод). Для тестов можно передать готовый клиент.
  constructor(url: string, client?: Queryable) {
    this.pool = client ?? (new Pool({ connectionString: url }) as Queryable);
  }

  async init() {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        telegram_id   BIGINT PRIMARY KEY,
        name          TEXT NOT NULL,
        gc_email      TEXT,
        gc_user_id    TEXT,
        tariff        TEXT NOT NULL,
        access_active BOOLEAN NOT NULL DEFAULT TRUE,
        access_until  TEXT
      );
      CREATE INDEX IF NOT EXISTS users_gc_email_idx ON users (lower(gc_email));

      CREATE TABLE IF NOT EXISTS profiles (
        telegram_id BIGINT PRIMARY KEY,
        niche       TEXT NOT NULL DEFAULT '',
        product     TEXT NOT NULL DEFAULT '',
        audience    TEXT NOT NULL DEFAULT '',
        avg_check   TEXT NOT NULL DEFAULT '',
        notes       TEXT NOT NULL DEFAULT '',
        updated_at  TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS dialogs (
        telegram_id BIGINT NOT NULL,
        agent_id    TEXT NOT NULL,
        messages    JSONB NOT NULL DEFAULT '[]',
        updated_at  TEXT NOT NULL,
        PRIMARY KEY (telegram_id, agent_id)
      );

      CREATE TABLE IF NOT EXISTS shared_history (
        telegram_id BIGINT PRIMARY KEY,
        messages    JSONB NOT NULL DEFAULT '[]'
      );

      CREATE TABLE IF NOT EXISTS usage (
        telegram_id   BIGINT NOT NULL,
        date          TEXT NOT NULL,
        requests      INTEGER NOT NULL DEFAULT 0,
        input_tokens  INTEGER NOT NULL DEFAULT 0,
        output_tokens INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (telegram_id, date)
      );
    `);
    console.log('  Хранилище: PostgreSQL (постоянное)');
  }

  // --- Пользователи / доступ ---
  async getUser(telegramId: number) {
    const { rows } = await this.pool.query<UserRow>('SELECT * FROM users WHERE telegram_id = $1', [telegramId]);
    return rows[0] ? rowToUser(rows[0]) : undefined;
  }

  async upsertUser(user: User) {
    await this.pool.query(
      `INSERT INTO users (telegram_id, name, gc_email, gc_user_id, tariff, access_active, access_until)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (telegram_id) DO UPDATE SET
         name = EXCLUDED.name,
         gc_email = EXCLUDED.gc_email,
         gc_user_id = EXCLUDED.gc_user_id,
         tariff = EXCLUDED.tariff,
         access_active = EXCLUDED.access_active,
         access_until = EXCLUDED.access_until`,
      [user.telegramId, user.name, user.gcEmail, user.gcUserId, user.tariff, user.accessActive, user.accessUntil],
    );
    return user;
  }

  async getUserByEmail(email: string) {
    const { rows } = await this.pool.query<UserRow>(
      'SELECT * FROM users WHERE lower(gc_email) = lower($1) LIMIT 1',
      [email.trim()],
    );
    return rows[0] ? rowToUser(rows[0]) : undefined;
  }

  async upsertGkUser(email: string, name?: string) {
    const existing = await this.getUserByEmail(email);
    if (existing) return existing;
    const user = newGkUser(email, name);
    await this.upsertUser(user);
    return user;
  }

  async setAccessByEmail(
    email: string,
    patch: Partial<Pick<User, 'tariff' | 'accessActive' | 'accessUntil' | 'gcUserId'>>,
  ) {
    const user = await this.getUserByEmail(email);
    if (!user) return undefined;
    const updated: User = { ...user, ...patch };
    await this.upsertUser(updated);
    return updated;
  }

  // --- Профиль ---
  async getProfile(telegramId: number) {
    const { rows } = await this.pool.query<{
      telegram_id: string;
      niche: string;
      product: string;
      audience: string;
      avg_check: string;
      notes: string;
      updated_at: string;
    }>(
      'SELECT telegram_id, niche, product, audience, avg_check, notes, updated_at FROM profiles WHERE telegram_id = $1',
      [telegramId],
    );
    const r = rows[0];
    if (!r) return undefined;
    return {
      telegramId: Number(r.telegram_id),
      niche: r.niche,
      product: r.product,
      audience: r.audience,
      avgCheck: r.avg_check,
      notes: r.notes,
      updatedAt: r.updated_at,
    } satisfies Profile;
  }

  async saveProfile(profile: Profile) {
    await this.pool.query(
      `INSERT INTO profiles (telegram_id, niche, product, audience, avg_check, notes, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (telegram_id) DO UPDATE SET
         niche = EXCLUDED.niche,
         product = EXCLUDED.product,
         audience = EXCLUDED.audience,
         avg_check = EXCLUDED.avg_check,
         notes = EXCLUDED.notes,
         updated_at = EXCLUDED.updated_at`,
      [profile.telegramId, profile.niche, profile.product, profile.audience, profile.avgCheck, profile.notes, profile.updatedAt],
    );
    return profile;
  }

  // --- История по агенту ---
  async getDialog(telegramId: number, agentId: string) {
    const { rows } = await this.pool.query<{ messages: ChatMessage[]; updated_at: string }>(
      'SELECT messages, updated_at FROM dialogs WHERE telegram_id = $1 AND agent_id = $2',
      [telegramId, agentId],
    );
    const r = rows[0];
    if (!r) return undefined;
    return {
      telegramId,
      agentId,
      messages: r.messages,
      updatedAt: r.updated_at,
    } satisfies DialogTurn;
  }

  async saveDialog(turn: DialogTurn) {
    await this.pool.query(
      `INSERT INTO dialogs (telegram_id, agent_id, messages, updated_at)
       VALUES ($1, $2, $3::jsonb, $4)
       ON CONFLICT (telegram_id, agent_id) DO UPDATE SET
         messages = EXCLUDED.messages,
         updated_at = EXCLUDED.updated_at`,
      [turn.telegramId, turn.agentId, JSON.stringify(turn.messages), turn.updatedAt],
    );
    return turn;
  }

  // --- Сквозная память ---
  async getSharedHistory(telegramId: number) {
    const { rows } = await this.pool.query<{ messages: ChatMessage[] }>(
      'SELECT messages FROM shared_history WHERE telegram_id = $1',
      [telegramId],
    );
    return rows[0] ? rows[0].messages : [];
  }

  async appendShared(telegramId: number, userMsg: ChatMessage, assistantMsg: ChatMessage) {
    await this.pool.query(
      `INSERT INTO shared_history (telegram_id, messages)
       VALUES ($1, $2::jsonb)
       ON CONFLICT (telegram_id) DO UPDATE SET
         messages = shared_history.messages || EXCLUDED.messages`,
      [telegramId, JSON.stringify([userMsg, assistantMsg])],
    );
  }

  // --- Учёт расходов ---
  async getUsageToday(telegramId: number) {
    const { rows } = await this.pool.query<{
      requests: number;
      input_tokens: number;
      output_tokens: number;
    }>(
      'SELECT requests, input_tokens, output_tokens FROM usage WHERE telegram_id = $1 AND date = $2',
      [telegramId, today()],
    );
    const r = rows[0];
    return {
      telegramId,
      date: today(),
      requests: r ? r.requests : 0,
      inputTokens: r ? r.input_tokens : 0,
      outputTokens: r ? r.output_tokens : 0,
    } satisfies UsageRecord;
  }

  async addUsage(telegramId: number, inputTokens: number, outputTokens: number) {
    await this.pool.query(
      `INSERT INTO usage (telegram_id, date, requests, input_tokens, output_tokens)
       VALUES ($1, $2, 1, $3, $4)
       ON CONFLICT (telegram_id, date) DO UPDATE SET
         requests = usage.requests + 1,
         input_tokens = usage.input_tokens + EXCLUDED.input_tokens,
         output_tokens = usage.output_tokens + EXCLUDED.output_tokens`,
      [telegramId, today(), inputTokens, outputTokens],
    );
  }
}
